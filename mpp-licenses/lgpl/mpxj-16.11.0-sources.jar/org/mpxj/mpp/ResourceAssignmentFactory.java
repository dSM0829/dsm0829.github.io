/*
 * file:       ResourceAssignmentFactory.java
 * author:     Jon Iles
 * copyright:  (c) Packwood Software 2010
 * date:       21/03/2010
 */

/*
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation; either version 2.1 of the License, or (at your
 * option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 */

package org.mpxj.mpp;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Stream;

import org.mpxj.AssignmentField;
import org.mpxj.DataType;
import org.mpxj.Duration;
import org.mpxj.FieldType;
import org.mpxj.FieldTypeClass;
import org.mpxj.ProjectCalendar;
import org.mpxj.ProjectFile;
import org.mpxj.ProjectProperties;
import org.mpxj.Resource;
import org.mpxj.ResourceAssignment;
import org.mpxj.ResourceType;
import org.mpxj.Task;
import org.mpxj.TimeUnit;
import org.mpxj.TimephasedCost;
import org.mpxj.TimephasedWork;
import org.mpxj.WorkContour;
import org.mpxj.common.AssignmentFieldLists;
import org.mpxj.common.ByteArrayHelper;
import org.mpxj.common.MicrosoftProjectConstants;
import org.mpxj.common.NumberHelper;

/**
 * Common implementation detail to extract resource assignment data from
 * MPP9, MPP12, and MPP14 files.
 */
class ResourceAssignmentFactory
{
   /**
    * Main entry point when called to process assignment data.
    *
    * @param file parent project file
    * @param fieldMap assignment field map
    * @param enterpriseCustomFieldMap enterprise custom field map
    * @param alternateVarDataMap alternate locations to retrieve values from var data
    * @param useRawTimephasedData use raw timephased data flag
    * @param assnVarMeta var meta
    * @param assnVarData var data
    * @param assnFixedMeta fixed meta
    * @param assnFixedData fixed data
    * @param assnFixedData2 fixed data
    * @param count expected number of assignments
    */
   public void process(ProjectFile file, FieldMap fieldMap, FieldMap enterpriseCustomFieldMap, FieldMap alternateVarDataMap, boolean useRawTimephasedData, VarMeta assnVarMeta, Var2Data assnVarData, FixedMeta assnFixedMeta, FixedData assnFixedData, FixedData assnFixedData2, int count)
   {
      Set<Integer> set = assnVarMeta.getUniqueIdentifierSet();
      TimephasedDataFactory timephasedFactory = new TimephasedDataFactory();
      HyperlinkReader hyperlinkReader = new HyperlinkReader();
      boolean editableActualCosts = file.getProjectProperties().getEditableActualCosts();

      //      System.out.println(assnFixedMeta);
      //      System.out.println(assnFixedData);
      //      System.out.println(assnFixedData2);
      //      System.out.println(assnVarMeta.toString(fieldMap));
      //      System.out.println(assnVarData);

      MppBitFlag[] metaDataBitFlags;
      if (NumberHelper.getInt(file.getProjectProperties().getMppFileType()) == 14)
      {
         if (NumberHelper.getInt(file.getProjectProperties().getApplicationVersion()) > ApplicationVersion.PROJECT_2010)
         {
            metaDataBitFlags = PROJECT_2013_ASSIGNMENT_META_DATA_BIT_FLAGS;
         }
         else
         {
            metaDataBitFlags = PROJECT_2010_ASSIGNMENT_META_DATA_BIT_FLAGS;
         }
      }
      else
      {
         metaDataBitFlags = ASSIGNMENT_META_DATA_BIT_FLAGS;
      }

      for (int loop = 0; loop < count; loop++)
      {
         byte[] meta = assnFixedMeta.getByteArrayValue(loop);
         if (meta == null || meta[0] != 0)
         {
            continue;
         }

         int offset = ByteArrayHelper.getInt(meta, 4);
         byte[] data = assnFixedData.getByteArrayValue(assnFixedData.getIndexFromOffset(offset));
         if (data == null)
         {
            continue;
         }

         if (data.length < fieldMap.getMaxFixedDataSize(0))
         {
            byte[] newData = new byte[fieldMap.getMaxFixedDataSize(0)];
            System.arraycopy(data, 0, newData, 0, data.length);
            data = newData;
         }

         int id = ByteArrayHelper.getInt(data, fieldMap.getFixedDataOffset(AssignmentField.UNIQUE_ID));
         final Integer varDataId = Integer.valueOf(id);
         if (!set.contains(varDataId))
         {
            continue;
         }

         byte[] data2 = null;
         if (assnFixedData2 != null)
         {
            data2 = assnFixedData2.getByteArrayValue(assnFixedData.getIndexFromOffset(offset));
         }

         Task task = file.getTaskByUniqueID(Integer.valueOf(ByteArrayHelper.getInt(data, fieldMap.getFixedDataOffset(AssignmentField.TASK_UNIQUE_ID))));
         if (task == null)
         {
            continue;
         }

         Resource resource = file.getResourceByUniqueID(Integer.valueOf(ByteArrayHelper.getInt(data, fieldMap.getFixedDataOffset(AssignmentField.RESOURCE_UNIQUE_ID))));
         if (task.getExistingResourceAssignment(resource) != null)
         {
            continue;
         }

         ResourceAssignment assignment = task.addResourceAssignment(resource);

         assignment.disableEvents();

         byte[][] fixedDataArray = new byte[][] {data, data2};
         fieldMap.populateContainer(FieldTypeClass.ASSIGNMENT, assignment, varDataId, fixedDataArray, assnVarData);

         if (enterpriseCustomFieldMap != null)
         {
            enterpriseCustomFieldMap.populateContainer(FieldTypeClass.ASSIGNMENT, assignment, varDataId, null, assnVarData);
         }

         if (alternateVarDataMap != null)
         {
            for (FieldType type : alternateVarDataMap.getFieldTypes())
            {
               // If a field is defined in the alternateVarDataMap, and we don't have a value
               // for it yet, try the using the alternative location.
               if (isDefaultValue(assignment, type))
               {
                  alternateVarDataMap.populateField(type, FieldTypeClass.ASSIGNMENT, assignment, varDataId, fixedDataArray, assnVarData);
               }
            }
         }

         assignment.enableEvents();

         Stream.of(metaDataBitFlags).forEach(f -> f.setValue(assignment, meta));

         // Map the null resource ID value to null
         if (NumberHelper.equals(assignment.getResourceUniqueID(), MicrosoftProjectConstants.ASSIGNMENT_NULL_RESOURCE_ID))
         {
            assignment.setResourceUniqueID(null);
         }

         hyperlinkReader.read(assignment, assnVarData.getByteArray(varDataId, fieldMap.getVarDataKey(AssignmentField.HYPERLINK_DATA)));

         //
         // Post-processing
         //
         if (NumberHelper.getInt(file.getProjectProperties().getMppFileType()) == 9 && assignment.getCreateDate() == null)
         {
            byte[] creationData = assnVarData.getByteArray(varDataId, MPP9_CREATION_DATA);
            if (creationData != null && creationData.length >= 28)
            {
               assignment.setCreateDate(MPPUtility.getTimestamp(creationData, 24));
            }
         }

         ProjectCalendar baselineCalendar = file.getBaselineCalendar();
         for (int index = 0; index < AssignmentFieldLists.RAW_TIMEPHASED_BASELINE_WORKS.length; index++)
         {
            List<TimephasedWork> baselineWork = timephasedFactory.getBaselineWork(baselineCalendar, assnVarData.getByteArray(varDataId, fieldMap.getVarDataKey(AssignmentFieldLists.RAW_TIMEPHASED_BASELINE_WORKS[index])));
            assignment.getRawTimephasedBaselineWork(index).addAll(baselineWork);

            List<TimephasedCost> baselineCost = timephasedFactory.getCost(baselineCalendar, assnVarData.getByteArray(varDataId, fieldMap.getVarDataKey(AssignmentFieldLists.RAW_TIMEPHASED_BASELINE_COSTS[index])));
            assignment.getRawTimephasedBaselineCost(index).addAll(baselineCost);

            List<TimephasedWork> baselineBudgetWork = timephasedFactory.getBaselineWork(baselineCalendar, assnVarData.getByteArray(varDataId, fieldMap.getVarDataKey(AssignmentFieldLists.RAW_TIMEPHASED_BASELINE_BUDGET_WORKS[index])));
            assignment.getRawTimephasedBaselineBudgetWork(index).addAll(baselineBudgetWork);

            List<TimephasedCost> baselineBudgetCost = timephasedFactory.getCost(baselineCalendar, assnVarData.getByteArray(varDataId, fieldMap.getVarDataKey(AssignmentFieldLists.RAW_TIMEPHASED_BASELINE_BUDGET_COSTS[index])));
            assignment.getRawTimephasedBaselineBudgetCost(index).addAll(baselineBudgetCost);
         }

         byte[] timephasedActualRegularWorkData = assnVarData.getByteArray(varDataId, fieldMap.getVarDataKey(AssignmentField.RAW_TIMEPHASED_ACTUAL_REGULAR_WORK));
         byte[] timephasedAdditionalWorkingHoursData = assnVarData.getByteArray(varDataId, fieldMap.getVarDataKey(AssignmentField.TIMEPHASED_ADDITIONAL_WORKING_HOURS));
         byte[] timephasedActualOvertimeWorkData = assnVarData.getByteArray(varDataId, fieldMap.getVarDataKey(AssignmentField.RAW_TIMEPHASED_ACTUAL_OVERTIME_WORK));
         byte[] timephasedWorkData = assnVarData.getByteArray(varDataId, fieldMap.getVarDataKey(AssignmentField.RAW_TIMEPHASED_REMAINING_REGULAR_WORK));
         byte[] timephasedBudgetCostData = assnVarData.getByteArray(varDataId, fieldMap.getVarDataKey(AssignmentField.RAW_TIMEPHASED_BUDGET_COST));
         byte[] timephasedBudgetWorkData = assnVarData.getByteArray(varDataId, fieldMap.getVarDataKey(AssignmentField.RAW_TIMEPHASED_BUDGET_WORK));

         ResourceType resourceType = resource == null ? ResourceType.WORK : resource.getType();
         ProjectCalendar calendar = assignment.getEffectiveCalendar();
         List<TimephasedWork> timephasedActualWork = timephasedFactory.getCompleteWork(assignment, timephasedActualRegularWorkData, timephasedAdditionalWorkingHoursData);
         List<TimephasedWork> timephasedWork = timephasedFactory.getPlannedWork(calendar, assignment, timephasedWorkData, timephasedActualWork, resourceType);
         List<TimephasedWork> timephasedActualOvertimeWork = timephasedFactory.getCompleteWork(assignment, timephasedActualOvertimeWorkData, timephasedAdditionalWorkingHoursData);
         List<TimephasedCost> budgetCost = getOrDefaultBudgetCost(assignment, () -> timephasedFactory.getCost(file.getDefaultCalendar(), timephasedBudgetCostData));
         List<TimephasedWork> budgetWork = getOrDefaultBudgetWork(assignment, () -> timephasedFactory.getBaselineWork(calendar, timephasedBudgetWorkData));

         if (task.getDuration() == null || task.getDuration().getDuration() == 0)
         {
            // If we have a zero duration task, we'll set the assignment actual start and finish based on the task actual start and finish
            assignment.setActualStart(task.getActualStart() != null ? assignment.getStart() : null);
            assignment.setActualFinish(task.getActualFinish() != null ? assignment.getFinish() : null);
         }
         else
         {
            // We have a task with a duration, try to determine the assignment actual start and finish values
            assignment.setActualFinish((task.getActualStart() != null && assignment.getRemainingWork().getDuration() == 0 && resource != null) ? assignment.getFinish() : null);
            assignment.setActualStart(assignment.getActualFinish() != null || !timephasedActualWork.isEmpty() ? assignment.getStart() : null);
         }

         createTimephasedData(file, assignment, timephasedWork, timephasedActualWork);

         assignment.getRawTimephasedRemainingRegularWork().addAll(timephasedWork);
         assignment.getRawTimephasedActualRegularWork().addAll(timephasedActualWork);
         assignment.getRawTimephasedActualOvertimeWork().addAll(timephasedActualOvertimeWork);
         assignment.getRawTimephasedBudgetCost().addAll(budgetCost);
         assignment.getRawTimephasedBudgetWork().addAll(budgetWork);

         if (timephasedWorkData != null)
         {
            // TODO: there is some additional logic around split tasks we need to account for,
            // the flag alone doesn't seem to be set for contoured split tasks.

            // If the assignment is contoured, this will already have been set by the time we get here.
            // If we're still set to flat, retrieve the actual work contour setting from the timephased data.
            if (assignment.getWorkContour() == WorkContour.FLAT)
            {
               if (timephasedWorkData.length >= 30)
               {
                  assignment.setWorkContour(WorkContourHelper.getInstance(file, ByteArrayHelper.getShort(timephasedWorkData, 28)));
               }
            }
         }

         if (editableActualCosts)
         {
            byte[] timephasedActualCostData = assnVarData.getByteArray(varDataId, fieldMap.getVarDataKey(AssignmentField.RAW_TIMEPHASED_ACTUAL_COST));
            List<TimephasedCost> actualCosts = timephasedFactory.getCost(calendar, timephasedActualCostData);
            assignment.getRawTimephasedActualCost().addAll(actualCosts);
         }

         file.getEventManager().fireAssignmentReadEvent(assignment);
      }
   }

   /**
    * Method used to create missing timephased data.
    *
    * @param file project file
    * @param assignment resource assignment
    * @param timephasedPlanned planned timephased data
    * @param timephasedComplete complete timephased data
    */
   private void createTimephasedData(ProjectFile file, ResourceAssignment assignment, List<TimephasedWork> timephasedPlanned, List<TimephasedWork> timephasedComplete)
   {
      if (!timephasedPlanned.isEmpty() || !timephasedComplete.isEmpty() || assignment.getTask().getDuration() == null || assignment.getTask().getDuration().getDuration() == 0)
      {
         return;
      }

      Duration totalWorkMinutes = assignment.getWork().convertUnits(TimeUnit.MINUTES, file.getProjectProperties());
      if (totalWorkMinutes.getDuration() == 0)
      {
         return;
      }

      Duration workPerHour;

      if (assignment.getResource() == null || assignment.getResource().getType() == ResourceType.WORK)
      {
         double units = NumberHelper.getDouble(assignment.getUnits());
         double workPerHourValue = ((totalWorkMinutes.getDuration() == 0 ? 0 : 60) * units) / 100.0;
         workPerHour = Duration.getInstance(workPerHourValue, TimeUnit.MINUTES);
      }
      else
      {
         if (assignment.getVariableRateUnits() == null)
         {
            Duration workingHours = assignment.getEffectiveCalendar().getWork(assignment.getStart(), assignment.getFinish(), TimeUnit.HOURS);
            double units = NumberHelper.getDouble(assignment.getUnits());
            double unitsPerHourAsMinutes = units / (workingHours.getDuration() * 100);
            workPerHour = Duration.getInstance(unitsPerHourAsMinutes, TimeUnit.MINUTES);
         }
         else
         {
            double units = NumberHelper.getDouble(assignment.getUnits());
            double workPerHourValue = ((totalWorkMinutes.getDuration() == 0 ? 0 : 60) * units) / 100.0;
            workPerHour = Duration.getInstance(workPerHourValue, TimeUnit.MINUTES);
         }
      }

      Duration overtimeWork = assignment.getOvertimeWork();
      if (overtimeWork != null && overtimeWork.getDuration() != 0)
      {
         Duration totalOvertimeMinutes = overtimeWork.convertUnits(TimeUnit.MINUTES, file.getProjectProperties());
         totalWorkMinutes = Duration.getInstance(totalWorkMinutes.getDuration() - totalOvertimeMinutes.getDuration(), TimeUnit.MINUTES);
      }

      TimephasedWork tra = new TimephasedWork();
      tra.setStart(assignment.getStart());
      tra.setAmountPerHour(workPerHour);
      tra.setFinish(assignment.getFinish());
      tra.setTotalAmount(totalWorkMinutes);
      timephasedPlanned.add(tra);
   }

   /**
    * Retrieve or generate timephased budget cost data.
    *
    * @param assignment resource assignment
    * @param supplier timephased cost supplier
    * @return timephased budget cost data
    */
   private List<TimephasedCost> getOrDefaultBudgetCost(ResourceAssignment assignment, Supplier<List<TimephasedCost>> supplier)
   {
      Resource resource = assignment.getResource();
      if (resource == null || !resource.getBudget() || resource.getType() != ResourceType.COST)
      {
         return Collections.emptyList();
      }

      List<TimephasedCost> timephasedCosts = supplier.get();
      if (!timephasedCosts.isEmpty())
      {
         return timephasedCosts;
      }

      Number budgetCost = assignment.getBudgetCost();
      if (budgetCost == null)
      {
         return Collections.emptyList();
      }

      ProjectProperties props = assignment.getParentFile().getProjectProperties();
      ProjectCalendar calendar = assignment.getParentFile().getDefaultCalendar();
      double hours = calendar.getWork(props.getStartDate(), props.getFinishDate(), TimeUnit.HOURS).getDuration();
      Double amountPerHour = Double.valueOf(budgetCost.doubleValue() / hours);

      TimephasedCost cost = new TimephasedCost();
      cost.setStart(props.getStartDate());
      cost.setAmountPerHour(amountPerHour);
      cost.setFinish(props.getFinishDate());
      cost.setTotalAmount(budgetCost);

      return Collections.singletonList(cost);
   }

   /**
    * Retrieve or generate timephased budget work data.
    *
    * @param assignment resource assignment
    * @param supplier timephased work supplier
    * @return timephased budget work data
    */
   private List<TimephasedWork> getOrDefaultBudgetWork(ResourceAssignment assignment, Supplier<List<TimephasedWork>> supplier)
   {
      Resource resource = assignment.getResource();
      if (resource == null || !resource.getBudget() || resource.getType() != ResourceType.WORK)
      {
         return Collections.emptyList();
      }

      List<TimephasedWork> timephasedWork = supplier.get();
      if (!timephasedWork.isEmpty())
      {
         return timephasedWork;
      }

      Duration budgetWork = assignment.getBudgetWork();
      if (budgetWork == null)
      {
         return Collections.emptyList();
      }

      ProjectProperties props = assignment.getParentFile().getProjectProperties();
      ProjectCalendar calendar = assignment.getEffectiveCalendar();
      double hours = calendar.getWork(props.getStartDate(), props.getFinishDate(), TimeUnit.HOURS).getDuration();
      Duration amountPerHour = Duration.getInstance(budgetWork.getDuration() / hours, budgetWork.getUnits());

      TimephasedWork work = new TimephasedWork();
      work.setStart(props.getStartDate());
      work.setAmountPerHour(amountPerHour);
      work.setFinish(props.getFinishDate());
      work.setTotalAmount(budgetWork);

      return Collections.singletonList(work);
   }

   /**
    * Returns true if a field has a null or default value.
    *
    * @param assignment resource assignment
    * @param type field to test
    * @return true is the field has a null or default value
    */
   private boolean isDefaultValue(ResourceAssignment assignment, FieldType type)
   {
      Object value = assignment.get(type);

      if (Objects.requireNonNull(type.getDataType()) == DataType.CURRENCY)
      {
         return value == null || ((Double) value).doubleValue() == 0.0;
      }

      return value == null;
   }

   private static final Integer MPP9_CREATION_DATA = Integer.valueOf(138);

   private static final MppBitFlag[] ASSIGNMENT_META_DATA_BIT_FLAGS = {
      new MppBitFlag(AssignmentField.FLAG1, 28, 0x00000080, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG2, 28, 0x00000100, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG3, 28, 0x00000200, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG4, 28, 0x00000400, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG5, 28, 0x00000800, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG6, 28, 0x00001000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG7, 28, 0x00002000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG8, 28, 0x00004000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG9, 28, 0x00008000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG10, 28, 0x00000040, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG11, 28, 0x00010000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG12, 28, 0x00020000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG13, 28, 0x00040000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG14, 28, 0x00080000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG15, 28, 0x00100000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG16, 28, 0x00200000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG17, 28, 0x00400000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG18, 28, 0x00800000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG19, 28, 0x01000000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG20, 28, 0x02000000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.LINKED_FIELDS, 8, 0x00000008, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.WORK_CONTOUR, 8, 0x00000010, WorkContour.FLAT, WorkContour.CONTOURED),
      new MppBitFlag(AssignmentField.CONFIRMED, 8, 0x00000080, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.TEAM_STATUS_PENDING, 8, 0x00020000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.RESPONSE_PENDING, 8, 0x00000100, Boolean.FALSE, Boolean.TRUE)
   };

   private static final MppBitFlag[] PROJECT_2010_ASSIGNMENT_META_DATA_BIT_FLAGS = {
      new MppBitFlag(AssignmentField.FLAG10, 28, 0x000002, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG1, 28, 0x000004, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG2, 28, 0x000008, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG3, 28, 0x000010, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG4, 28, 0x000020, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG5, 28, 0x000040, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG6, 28, 0x000080, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG7, 28, 0x000100, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG8, 28, 0x000200, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG9, 28, 0x000400, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG11, 28, 0x000800, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG12, 28, 0x001000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG13, 28, 0x002000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG14, 28, 0x004000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG15, 28, 0x008000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG16, 28, 0x010000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG17, 28, 0x020000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG18, 28, 0x040000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG19, 28, 0x080000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG20, 28, 0x100000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.LINKED_FIELDS, 8, 0x00000008, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.WORK_CONTOUR, 8, 0x00000010, WorkContour.FLAT, WorkContour.CONTOURED),
      new MppBitFlag(AssignmentField.CONFIRMED, 8, 0x00000080, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.TEAM_STATUS_PENDING, 8, 0x00020000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.RESPONSE_PENDING, 8, 0x00000100, Boolean.FALSE, Boolean.TRUE)
   };

   private static final MppBitFlag[] PROJECT_2013_ASSIGNMENT_META_DATA_BIT_FLAGS = {
      new MppBitFlag(AssignmentField.FLAG1, 20, 0x000002, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG2, 20, 0x000004, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG3, 20, 0x000008, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG4, 20, 0x000010, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG5, 20, 0x000020, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG6, 20, 0x000040, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG7, 20, 0x000080, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG8, 20, 0x000100, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG9, 20, 0x000200, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.LINKED_FIELDS, 20, 0x00000400, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG10, 20, 0x000001, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG11, 25, 0x000008, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG12, 25, 0x000010, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG13, 25, 0x000020, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG14, 25, 0x000040, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG15, 25, 0x000080, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG16, 25, 0x000100, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG17, 25, 0x000200, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG18, 25, 0x000400, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG19, 25, 0x000800, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.FLAG20, 25, 0x001000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.WORK_CONTOUR, 8, 0x00040000, WorkContour.FLAT, WorkContour.CONTOURED),
      new MppBitFlag(AssignmentField.CONFIRMED, 8, 0x00800000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.TEAM_STATUS_PENDING, 8, 0x02000000, Boolean.FALSE, Boolean.TRUE),
      new MppBitFlag(AssignmentField.RESPONSE_PENDING, 8, 0x01000000, Boolean.FALSE, Boolean.TRUE)
   };
}
