/*
 * file:       PrimaveraScheduler.java
 * author:     Jon Iles
 * date:       2025-04-02
 */

/*
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation; either version 2.1 of the License, or (at your
 * option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 */

package org.mpxj.cpm;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.mpxj.ActivityType;
import org.mpxj.ConstraintType;
import org.mpxj.Duration;
import org.mpxj.LocalTimeRange;
import org.mpxj.PercentCompleteType;
import org.mpxj.ProjectCalendar;
import org.mpxj.ProjectFile;
import org.mpxj.Relation;
import org.mpxj.RelationType;
import org.mpxj.ResourceAssignment;
import org.mpxj.ResourceType;
import org.mpxj.Task;
import org.mpxj.TaskField;
import org.mpxj.TimeUnit;
import org.mpxj.common.LocalDateTimeHelper;
import org.mpxj.common.NumberHelper;

/**
 * Implements the Critical Path Method to schedule a project so
 * that the resulting schedule matches closely the results you'd see if
 * you scheduled the same project in Primavera P6.
 */
public class PrimaveraScheduler implements Scheduler
{
   @Override public void schedule(ProjectFile file, LocalDateTime startDate) throws CpmException
   {
      m_file = file;
      m_dataDate = file.getProjectProperties().getStatusDate();
      m_dateCalculator = new PrimaveraDateCalculator(m_file, () -> m_dataDate);
      m_useExpectedFinish = file.getProjectProperties().getUseExpectedFinishDates();

      m_projectStartDate = startDate;

      List<Task> activities = new DepthFirstGraphSort(m_file, PrimaveraScheduler::isActivity).sort();
      if (activities.isEmpty())
      {
         return;
      }

      validateActivities(activities);

      clearDates();

      if (m_dataDate == null)
      {
         m_dataDate = m_projectStartDate;
      }
      else
      {
         if (startDate.isBefore(m_dataDate))
         {
            m_projectStartDate = m_dataDate;
         }
      }

      forwardPass(activities);

      LocalDateTime mustFinishBy = m_file.getProjectProperties().getMustFinishBy();
      LocalDateTime earlyFinish = activities.stream().map(Task::getEarlyFinish).max(Comparator.naturalOrder()).orElseThrow(() -> new CpmException("Missing early finish date"));

      if (mustFinishBy == null || earlyFinish.isAfter(mustFinishBy))
      {
         m_forwardPassFinishDate = earlyFinish;
      }
      else
      {
         m_forwardPassFinishDate = mustFinishBy;
      }

      if (mustFinishBy == null)
      {
         m_backwardPassFinishDate = earlyFinish;
      }
      else
      {
         m_backwardPassFinishDate = mustFinishBy;
      }

      backwardPass(activities);

      activities.forEach(this::updateDates);

      levelOfEffortPass();

      // TODO: can we use or adapt RollupHelper?
      m_file.getChildTasks().forEach(this::rollupDates);

      wbsSummaryPass();

      calculateLongestPath(activities);

      m_file.getProjectProperties().setStartDate(m_file.getEarliestStartDate());
      m_file.getProjectProperties().setFinishDate(m_forwardPassFinishDate);
      m_file.getProjectProperties().setScheduledFinish(earlyFinish);
   }

   /**
    * Update Start, Finish, Planned Start, and Planned Finish dates.
    *
    * @param activity activity to update
    */
   private void updateDates(Task activity)
   {
      activity.setStart(activity.getActualStart() == null ? activity.getEarlyStart() : activity.getActualStart());
      activity.setFinish(activity.getActualFinish() == null ? activity.getEarlyFinish() : activity.getActualFinish());

      // P6 moves the planned start/finish dates for unstarted activities
      if (activity.getActualStart() == null)
      {
         activity.setPlannedStart(activity.getStart());
         activity.setPlannedFinish(activity.getFinish());
      }

      activity.getResourceAssignments().forEach(this::updateDates);
   }

   /**
    * Update the Remaining Early Start, Remaining Early Finish, Remaining Late Start, Remaining Late Finish, Start, Finish, Planned Start, and Planned Finish dates.
    *
    * @param assignment resource assignment to update
    */
   private void updateDates(ResourceAssignment assignment)
   {
      Task activity = assignment.getTask();
      if (activity.getActualFinish() != null)
      {
         assignment.setRemainingEarlyStart(null);
         assignment.setRemainingEarlyFinish(null);
         assignment.setRemainingLateStart(null);
         assignment.setRemainingLateFinish(null);
         return;
      }

      if (assignment.getActualFinish() != null)
      {
         assignment.setRemainingEarlyStart(activity.getRemainingEarlyStart());
         assignment.setRemainingEarlyFinish(activity.getRemainingEarlyStart());
         assignment.setRemainingLateStart(activity.getRemainingLateFinish());
         assignment.setRemainingLateFinish(activity.getRemainingLateFinish());
         assignment.setStart(assignment.getActualStart());
         assignment.setFinish(assignment.getActualFinish());
         return;
      }

      LocalDateTime earlyStart = activity.getRemainingEarlyStart();
      LocalDateTime lateFinish = activity.getRemainingLateFinish();
      LocalDateTime earlyFinish;
      LocalDateTime lateStart;

      ProjectCalendar governingCalendar = getEffectiveCalendar(assignment);
      Duration atCompletionWork = assignment.getWork();
      Duration plannedWork = governingCalendar.getWork(assignment.getPlannedStart(), assignment.getPlannedFinish(), TimeUnit.HOURS);

      if (assignment.getResource().getType() != ResourceType.NON_LABOR && assignment.getActualStart() == null && atCompletionWork.getDuration() == 0.0 && plannedWork.getDuration() != 0.0)
      {
         // No computable duration - fall back on planned duration
         if (assignment.getActualStart() == null)
         {
            Duration lag = assignment.getDelay();
            Duration remainingLag = assignment.getRemainingDelay();
            if (lag != null && lag.getDuration() != 0 && remainingLag != null && remainingLag.getDuration() != 0)
            {
               earlyStart = governingCalendar.getNextWorkStart(governingCalendar.getDate(earlyStart, remainingLag));
            }
         }

         earlyFinish = governingCalendar.getDate(earlyStart, plannedWork);
         lateStart = governingCalendar.getDate(lateFinish, plannedWork.negate());
      }
      else
      {
         Duration remainingWork = assignment.getRemainingWork();
         if (remainingWork.getDuration() == 0.0 || activity.getActivityType() == ActivityType.LEVEL_OF_EFFORT)
         {
            earlyFinish = activity.getRemainingEarlyFinish();
            lateStart = activity.getRemainingLateStart();
         }
         else
         {
            if (assignment.getActualStart() == null)
            {
               Duration lag = assignment.getDelay();
               Duration remainingLag = assignment.getRemainingDelay();
               if (lag != null && lag.getDuration() != 0 && remainingLag != null && remainingLag.getDuration() != 0)
               {
                  earlyStart = governingCalendar.getNextWorkStart(governingCalendar.getDate(earlyStart, remainingLag));
               }
            }

            earlyFinish = getDateFromWork(governingCalendar, assignment.getRemainingUnits(), earlyStart, remainingWork);
            lateStart = getDateFromWork(governingCalendar, assignment.getRemainingUnits(), lateFinish, remainingWork.negate());
         }
      }

      assignment.setRemainingEarlyStart(earlyStart);
      assignment.setRemainingEarlyFinish(earlyFinish);
      assignment.setRemainingLateStart(lateStart);
      assignment.setRemainingLateFinish(lateFinish);

      if (activity.getActualStart() == null && (assignment.getPlannedStart() == null || assignment.getRemainingEarlyStart().isAfter(assignment.getPlannedStart())))
      {
         assignment.setPlannedStart(assignment.getRemainingEarlyStart());
         assignment.setPlannedFinish(assignment.getRemainingEarlyFinish());
      }

      assignment.setStart(assignment.getActualStart() == null ? assignment.getRemainingEarlyStart() : assignment.getActualStart());
      assignment.setFinish(assignment.getRemainingEarlyFinish());
   }

   /**
    * Determine the effective calendar to use for the given resource assignment.
    *
    * @param assignment resource assignment.
    * @return effective calendar
    */
   private ProjectCalendar getEffectiveCalendar(ResourceAssignment assignment)
   {
      return assignment.getTask().getActivityType() == ActivityType.RESOURCE_DEPENDENT ? assignment.getResource().getCalendar() : assignment.getEffectiveCalendar();
   }

   /**
    * Ensure that the activities in the project can be scheduled.
    *
    * @param tasks activities from the project
    */
   private void validateActivities(List<Task> tasks) throws CpmException
   {
      for (Task task : tasks)
      {
         if (task.getActivityType() == null)
         {
            throw new CpmException("Task has no activity type: " + task);
         }

         if (task.getActivityType() == ActivityType.RESOURCE_DEPENDENT && getResourceAssignmentStream(task).findAny().isPresent())
         {
            if (getResourceAssignmentStream(task).anyMatch(r -> r.getWork() == null))
            {
               throw new CpmException("Task has resource assignments without a work value: " + task);
            }

            if (getResourceAssignmentStream(task).anyMatch(r -> r.getRemainingWork() == null))
            {
               throw new CpmException("Task has resource assignments without a remaining work value: " + task);
            }
         }
         else
         {
            if (task.getDuration() == null)
            {
               throw new CpmException("Task has no duration value: " + task);
            }

            if (task.getRemainingDuration() == null)
            {
               throw new CpmException("Task has no remaining duration value: " + task);
            }
         }
      }
   }

   /**
    * Perform the CPM forward pass.
    *
    * @param tasks tasks in order for forward pass
    */
   private void forwardPass(List<Task> tasks) throws CpmException
   {
      for (Task task : tasks)
      {
         forwardPass(task);
      }
   }

   /**
    * Perform the CPM forward pass for this task.
    *
    * @param task task to schedule
    */
   private void forwardPass(Task task) throws CpmException
   {
      LocalDateTime earlyStart;
      List<DrivingRelation> drivingRelations = Collections.emptyList();
      LocalDateTime earlyFinish = null;
      List<Relation> predecessors = task.getPredecessors().stream().filter(r -> isActivity(r.getPredecessorTask())).collect(Collectors.toList());

      if (task.getActualStart() == null)
      {
         if (predecessors.isEmpty())
         {
            switch (getConstraintType(task))
            {
               case START_NO_EARLIER_THAN:
               {
                  earlyStart = task.getConstraintDate();
                  if (earlyStart.isBefore(m_dataDate))
                  {
                     earlyStart = m_dataDate;
                  }
                  break;
               }

               case FINISH_NO_EARLIER_THAN:
               {
                  earlyFinish = task.getConstraintDate();
                  if (!isWorkingTime(task, earlyFinish))
                  {
                     earlyFinish = getEquivalentNextWorkStart(task, earlyFinish);
                  }

                  earlyStart = getDateFromFinishAndDuration(task, earlyFinish);
                  break;
               }

               default:
               {
                  earlyStart = m_projectStartDate;
                  break;
               }
            }
         }
         else
         {
            drivingRelations = getForwardPassDrivingRelations(task, predecessors);
            earlyStart = drivingRelations.get(0).getStartDate();
            if (earlyStart.isBefore(m_projectStartDate))
            {
               earlyStart = m_projectStartDate;
            }
            else
            {
               earlyFinish = drivingRelations.get(0).getFinishDate();
            }
         }

         switch (getConstraintType(task))
         {
            case START_NO_EARLIER_THAN:
            {
               if (earlyStart.isBefore(task.getConstraintDate()) || earlyStart.toLocalDate().isEqual(task.getConstraintDate().toLocalDate()))
               {
                  LocalDateTime constraintDate = task.getConstraintDate();

                  // I have an example where the applied constraint date seems to inherit the
                  // time component of the early start date it is replacing.
                  // Need more samples to determine if the logic here is anything like correct!
                  if (constraintDate.toLocalTime() == LocalTime.MIDNIGHT && earlyStart.toLocalTime() != LocalTime.MIDNIGHT)
                  {
                     LocalDateTime adjustedConstraintDate = LocalDateTime.of(constraintDate.toLocalDate(), earlyStart.toLocalTime());
                     if (adjustedConstraintDate.toLocalDate().isEqual(getNextWorkStart(task, adjustedConstraintDate).toLocalDate()))
                     {
                        constraintDate = adjustedConstraintDate;
                     }
                  }

                  drivingRelations.clear();
                  earlyStart = constraintDate;
               }
               break;
            }

            case FINISH_NO_EARLIER_THAN:
            {
               LocalDateTime earliestStart = getDateFromFinishAndDuration(task, task.getConstraintDate());
               if (earlyStart.isBefore(earliestStart))
               {
                  drivingRelations.clear();
                  earlyStart = earliestStart;
                  earlyFinish = null;
               }
               break;
            }

            case MUST_START_ON:
            {
               earlyStart = task.getConstraintDate();
               break;
            }

            case START_ON:
            {
               if (earlyStart.isBefore(task.getConstraintDate()))
               {
                  drivingRelations.clear();
                  earlyStart = getNextWorkStart(task, task.getConstraintDate());
               }
               break;
            }

            case MUST_FINISH_ON:
            {
               drivingRelations.clear();
               earlyFinish = task.getConstraintDate();
               earlyStart = getDateFromFinishAndDuration(task, earlyFinish);
               break;
            }

            case FINISH_ON:
            {
               LocalDateTime startOn = getDateFromFinishAndDuration(task, task.getConstraintDate());
               if (startOn.isAfter(earlyStart))
               {
                  drivingRelations.clear();
                  earlyStart = startOn;
                  if (task.getActivityType() == ActivityType.FINISH_MILESTONE)
                  {
                     earlyFinish = startOn;
                  }
                  else
                  {
                     earlyFinish = getEquivalentPreviousWorkFinish(task, task.getConstraintDate());
                  }
               }
               break;
            }

            default:
            {
               break;
            }
         }

         if (task.getActivityType() == ActivityType.FINISH_MILESTONE)
         {
            // Don't adjust early start for a finish milestone unless we're not aligned with a work finish
            if (!earlyStart.isEqual(getEquivalentPreviousWorkFinish(task, earlyStart)))
            {
               earlyStart = getNextWorkStart(task, earlyStart);
            }
         }
         else
         {
            // Next work start
            earlyStart = getNextWorkStart(task, earlyStart);
            if (task.getActivityType() == ActivityType.START_MILESTONE)
            {
               earlyFinish = earlyStart;
            }
         }
      }
      else
      {
         if (task.getActualFinish() == null)
         {
            if (predecessors.isEmpty())
            {
               if (!hasActualDuration(task))
               {
                  earlyStart = getNextWorkStart(task, m_dataDate);
                  earlyFinish = getDateFromStartAndDuration(task, earlyStart);
               }
               else
               {
                  if (hasRemainingDuration(task))
                  {
                     earlyFinish = getDateFromStartAndDuration(task, task.getActualStart());
                     // Sometimes this instead... not sure why?
                     //earlyFinish = getNextWorkStart(task, getDateFromStart(task, task.getActualStart()));
                     earlyStart = getDateFromFinishAndRemainingDuration(task, earlyFinish);
                  }
                  else
                  {
                     earlyStart = getNextWorkStart(task, m_dataDate);
                     earlyFinish = earlyStart;
                  }
               }
            }
            else
            {
               drivingRelations = getForwardPassDrivingRelations(task, predecessors);
               earlyStart = getNextWorkStart(task, drivingRelations.get(0).getStartDate());
               if (earlyStart.isBefore(m_projectStartDate))
               {
                  earlyStart = getNextWorkStart(task, m_projectStartDate);
               }
               earlyFinish = getDateFromStartAndRemainingDuration(task, earlyStart);
            }
         }
         else
         {
            if (predecessors.isEmpty())
            {
               earlyStart = m_dataDate;
               earlyFinish = m_dataDate;
            }
            else
            {
               drivingRelations = getForwardPassDrivingRelations(task, predecessors);
               earlyStart = drivingRelations.get(0).getStartDate();
               if (earlyStart.isBefore(m_projectStartDate))
               {
                  earlyStart = m_projectStartDate;
               }
               earlyFinish = getDateFromStartAndRemainingDuration(task, earlyStart);
            }
         }
      }

      if (task.getExternalEarlyStart() != null && task.getExternalEarlyStart().isAfter(earlyStart))
      {
         earlyStart = task.getExternalEarlyStart();
         earlyFinish = null;
      }

      if (earlyFinish == null)
      {
         earlyFinish = task.getActualFinish() == null ? getDateFromStartAndDuration(task, earlyStart) : task.getActualFinish();
      }

      task.setEarlyStart(earlyStart);
      task.setEarlyFinish(earlyFinish);

      setRemainingEarlyDates(task);

      if (task.getConstraintType() != ConstraintType.AS_LATE_AS_POSSIBLE || task.getActualFinish() != null)
      {
         drivingRelations.forEach(d -> d.getRelation().setDriving(true));
      }

      // Rather than calculating Early Finish from Remaining Duration,
      // Expected Finish allows the user to set Early Finish, and P6 will calculate
      // the Remaining Duration from that.
      if (m_useExpectedFinish &&
         task.getExpectedFinish() != null && // We have an expected finish date
         task.getActualFinish() == null && // The activity is not complete
         task.getConstraintType() != ConstraintType.AS_LATE_AS_POSSIBLE && // ALAP will override early finish
         !task.getExpectedFinish().isBefore(earlyStart) && // The expected finish is >= early start
         !task.getExpectedFinish().isBefore(m_dataDate) && // The expected finish is >= the data date
         !taskHasFinishDrivingPredecessor(task) && // FF and SF predecessors (appear to) override Expected Finish
         task.getEffectiveCalendar().getWork(task.getEarlyFinish(), task.getExpectedFinish(), TimeUnit.HOURS).getDuration() != 0) // Expected Finish  actually has an effect
      {
         task.setEarlyFinish(task.getExpectedFinish());
         task.setRemainingEarlyFinish(task.getExpectedFinish());
         task.setRemainingDuration(task.getEffectiveCalendar().getWork(task.getRemainingEarlyStart(), task.getEarlyFinish(), TimeUnit.HOURS));
      }

      updateDurationsAndPercentComplete(task);
   }

   /**
    * Returns true if the task has any predecessors which are SF or FF.
    *
    * @param task target task
    * @return true if predecessor drives finish date
    */
   private boolean taskHasFinishDrivingPredecessor(Task task)
   {
      return task.getPredecessors().stream().anyMatch(r -> r.getType() == RelationType.FINISH_FINISH || r.getType() == RelationType.START_FINISH);
   }

   /**
    * Update the Actual, Remaining, and At Completion Durations,
    * along with Duration Percent Complete.
    *
    * @param task target task
    */
   private void updateDurationsAndPercentComplete(Task task)
   {
      if (task.getPercentCompleteType() == PercentCompleteType.PHYSICAL)
      {
         return;
      }

      if (task.getActualStart() == null)
      {
         return;
      }

      if (task.getActualFinish() != null)
      {
         return;
      }

      Duration actualDuration;
      if (m_dataDate.isBefore(task.getActualStart()))
      {
         actualDuration = Duration.getInstance(0, TimeUnit.HOURS);
      }
      else
      {
         LocalDateTime endDate;
         Duration suspendedDuration = null;

         if (task.getSuspendDate() == null)
         {
            endDate = m_dataDate;
         }
         else
         {
            if (task.getSuspendDate().isAfter(m_dataDate))
            {
               endDate = m_dataDate;
            }
            else
            {
               if (task.getResume() != null && m_dataDate.isAfter(task.getResume()))
               {
                  endDate = m_dataDate;
                  suspendedDuration = task.getEffectiveCalendar().getWork(task.getSuspendDate(), task.getResume(), TimeUnit.HOURS);
               }
               else
               {
                  endDate = task.getSuspendDate();
               }
            }
         }

         actualDuration = task.getEffectiveCalendar().getWork(task.getActualStart(), endDate, TimeUnit.HOURS);
         if (suspendedDuration != null)
         {
            actualDuration = Duration.getInstance(actualDuration.getDuration() - suspendedDuration.getDuration(), TimeUnit.HOURS);
         }
      }

      Duration remainingDuration = task.getEffectiveCalendar().getWork(task.getRemainingEarlyStart(), task.getEarlyFinish(), TimeUnit.HOURS);

      task.setActualDuration(actualDuration);
      task.setRemainingDuration(remainingDuration);
      task.setDuration(calculateAtCompletionDuration(task));
      task.setPercentageComplete(calculateDurationPercentComplete(task));
   }

   /**
    * Calculate the At Completion duration.
    *
    * @param task target task
    * @return At Completion duration
    */
   private Duration calculateAtCompletionDuration(Task task)
   {
      Duration actualDuration = task.getActualDuration();

      if (actualDuration != null && actualDuration.getDuration() == 0.0)
      {
         return task.getRemainingDuration();
      }

      if (task.getRemainingDuration().getDuration() == 0.0)
      {
         return actualDuration;
      }

      return task.getEffectiveCalendar().getWork(task.getActualStart(), task.getEarlyFinish(), TimeUnit.HOURS);
   }

   /**
    * Calculate the duration percent complete for a task.
    *
    * @param task target task
    * @return duration percent complete value
    */
   private Number calculateDurationPercentComplete(Task task)
   {
      Duration target = task.getPlannedDuration();
      Duration remaining = task.getRemainingDuration();
      double targetDuration = target == null ? 0 : target.getDuration();
      double remainingDuration = remaining == null ? 0 : remaining.getDuration();

      double result = 0;
      if (targetDuration == 0)
      {
         if (remainingDuration == 0)
         {
            result = 100;
         }
      }
      else
      {
         if (remainingDuration < targetDuration)
         {
            result = ((targetDuration - remainingDuration) * 100) / targetDuration;
         }
      }

      return NumberHelper.getDouble(result);
   }

   /**
    * Populate a list of driving relations for the supplied task.
    *
    * @param task target task
    * @param predecessors task predecessors
    * @return list of DrivingRelation instances
    */
   private List<DrivingRelation> getForwardPassDrivingRelations(Task task, List<Relation> predecessors) throws CpmException
   {
      List<DrivingRelation> relations = predecessors.stream().map(this::calculateEarlyStart).collect(Collectors.toList());
      LocalDateTime earlyStart = relations.stream().map(d -> getNextWorkStart(task, d.getStartDate())).max(Comparator.naturalOrder()).orElseThrow(() -> new CpmException("Missing early start date"));
      relations.removeIf(r -> !getNextWorkStart(task, r.getStartDate()).isEqual(earlyStart));
      return relations;
   }

   /**
    * Retrieve the driving relation used by the backward pass.
    *
    * @param successors successo activities
    * @return driving relation
    */
   private DrivingRelation getBackwardPassDrivingRelation(List<Relation> successors)
   {
      List<DrivingRelation> drivingRelations = successors.stream().map(this::calculateLateFinish).collect(Collectors.toList());
      return drivingRelations.stream().min(Comparator.comparing(DrivingRelation::getFinishDate)).orElse(null);
   }

   /**
    * Perform the CPM backward pass.
    *
    * @param forwardPassTasks tasks in order for forward pass
    */
   private void backwardPass(List<Task> forwardPassTasks) throws CpmException
   {
      List<Task> tasks = new ArrayList<>(forwardPassTasks);
      Collections.reverse(tasks);

      for (Task task : tasks)
      {
         backwardPass(task);
      }
   }

   /**
    * Perform the CPM backward pass for this task.
    *
    * @param task task to schedule
    */
   private void backwardPass(Task task) throws CpmException
   {
      List<Relation> successors = m_file.getRelations().getSuccessors(task).stream().filter(r -> isActivity(r.getSuccessorTask())).collect(Collectors.toList());
      LocalDateTime lateFinish;
      LocalDateTime lateStart = null;

      if (task.getActualFinish() == null)
      {
         if (successors.isEmpty())
         {
            if (task.getExternalLateFinish() == null)
            {
               if (m_file.getProjectProperties().getMustFinishBy() != null)
               {
                  lateFinish = m_file.getProjectProperties().getMustFinishBy();
                  if (!isWorkingTime(task, lateFinish))
                  {
                     lateFinish = getEquivalentPreviousWorkFinish(task, lateFinish);
                  }
               }
               else
               {
                  lateFinish = m_backwardPassFinishDate;
               }
            }
            else
            {
               lateFinish = task.getExternalLateFinish();
            }
         }
         else
         {
            DrivingRelation drivingRelation = getBackwardPassDrivingRelation(successors);
            lateStart = drivingRelation.getStartDate();
            lateFinish = drivingRelation.getFinishDate();

            if (lateFinish.isAfter(m_backwardPassFinishDate))
            {
               // If we're between working periods, move back to the last work finish
               lateStart = null;
               lateFinish = getEquivalentPreviousWorkFinish(drivingRelation.getRelation().getPredecessorTask(), m_backwardPassFinishDate);
            }
         }

         switch (getConstraintType(task))
         {
            case START_ON:
            {
               if (task.getActualStart() == null)
               {
                  LocalDateTime latestFinish = getDateFromStartAndDuration(task, task.getConstraintDate());
                  if (lateFinish.isAfter(latestFinish))
                  {
                     if (lateStart != null)
                     {
                        lateStart = task.getConstraintDate();
                     }

                     lateFinish = latestFinish;
                     if (!isWorkingTime(task, lateFinish))
                     {
                        lateFinish = getEquivalentPreviousWorkFinish(task, lateFinish);
                     }
                  }
               }
               break;
            }

            case MUST_START_ON:
            {
               if (task.getActualStart() == null)
               {
                  lateFinish = getDateFromStartAndDuration(task, task.getConstraintDate());
               }
               break;
            }

            case MUST_FINISH_ON:
            {
               lateFinish = task.getConstraintDate();
               break;
            }

            case START_NO_LATER_THAN:
            {
               LocalDateTime latestFinish = getDateFromStartAndDuration(task, task.getConstraintDate());
               if (lateFinish.isAfter(latestFinish))
               {
                  lateFinish = latestFinish;
               }
               break;
            }

            case FINISH_ON:
            case FINISH_NO_LATER_THAN:
            {
               if (lateFinish.isAfter(task.getConstraintDate()))
               {
                  lateStart = null;
                  lateFinish = task.getConstraintDate();
               }
               break;
            }

            default:
            {
               break;
            }
         }

         if (task.getSecondaryConstraintType() != null)
         {
            switch (task.getSecondaryConstraintType())
            {
               case START_NO_LATER_THAN:
               {
                  LocalDateTime latestFinish = getDateFromStartAndDuration(task, task.getSecondaryConstraintDate());
                  if (lateFinish.isAfter(latestFinish))
                  {
                     if (lateStart != null)
                     {
                        lateStart = task.getSecondaryConstraintDate();
                     }
                     lateFinish = latestFinish;
                  }
                  break;
               }

               case FINISH_NO_LATER_THAN:
               {
                  if (lateFinish.isAfter(task.getSecondaryConstraintDate()))
                  {
                     lateFinish = task.getSecondaryConstraintDate();
                  }
                  break;
               }

               default:
               {
                  break;
               }
            }
         }

         // If we are at the start of the next period of work, we can move back to the end of the previous period of work
         if (task.getActivityType() != ActivityType.START_MILESTONE)
         {
            lateFinish = getEquivalentPreviousWorkFinish(task, lateFinish);
         }
      }
      else
      {
         if (successors.isEmpty())
         {
            if (m_file.getProjectProperties().getMustFinishBy() != null)
            {
               lateFinish = m_file.getProjectProperties().getMustFinishBy();
            }
            else
            {
               lateFinish = m_backwardPassFinishDate;
            }
         }
         else
         {
            DrivingRelation drivingRelation = getBackwardPassDrivingRelation(successors);
            lateFinish = adjustLateFinish(drivingRelation.getRelation(), drivingRelation.getFinishDate());
         }
      }

      if (task.getExternalLateFinish() != null && task.getExternalLateFinish().isBefore(lateFinish))
      {
         lateFinish = task.getExternalLateFinish();
      }

      if (lateStart == null)
      {
         lateStart = getDateFromFinishAndRemainingDuration(task, lateFinish);
         if (task.getActivityType() != ActivityType.START_MILESTONE && task.getActivityType() != ActivityType.FINISH_MILESTONE && hasRemainingDuration(task))
         {
            lateStart = getNextWorkStart(task, lateStart);
         }
      }

      task.setLateStart(lateStart);
      task.setLateFinish(lateFinish);
      setRemainingLateDates(task);

      if (task.getConstraintType() == ConstraintType.AS_LATE_AS_POSSIBLE)
      {
         alapAdjust(task);
      }
   }

   /**
    * Calculate the early start for the successor task in this relationship.
    *
    * @param relation relationship between two tasks
    * @return A DrivingRelation instance representing the calculated early start date
    */
   private DrivingRelation calculateEarlyStart(Relation relation)
   {
      LocalDateTime earlyStart;

      switch (relation.getType())
      {
         case FINISH_START:
         {
            earlyStart = calculateEarlyStartForFinishStart(relation);
            break;
         }

         case START_START:
         {
            earlyStart = calculateEarlyStartForStartStart(relation);
            break;
         }

         case FINISH_FINISH:
         {
            return calculateEarlyStartForFinishFinish(relation);
         }

         case START_FINISH:
         {
            return calculateEarlyStartForStartFinish(relation);
         }

         default:
         {
            throw new UnsupportedOperationException();
         }
      }

      return new DrivingRelation(relation, earlyStart, null);
   }

   /**
    * Calculate the early start for the successor task in a finish-start relationship.
    *
    * @param relation relationship between two tasks
    * @return calculated early start date
    */
   private LocalDateTime calculateEarlyStartForFinishStart(Relation relation)
   {
      Task predecessorTask = relation.getPredecessorTask();
      Task successorTask = relation.getSuccessorTask();
      LocalDateTime earlyStart;

      if (predecessorTask.getActualStart() == null)
      {
         // Predecessor not started
         if (successorTask.getActualStart() == null)
         {
            // Successor not started
            if (relation.getLag().getDuration() == 0)
            {
               earlyStart = predecessorTask.getEarlyFinish();
            }
            else
            {
               if (relation.getLag().getDuration() > 0)
               {
                  earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
               }
               else
               {
                  earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
               }
            }
         }
         else
         {
            // successor started
            if (successorTask.getActualFinish() == null)
            {
               // successor not finished
               if (relation.getLag().getDuration() == 0)
               {
                  earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
                  }
                  else
                  {
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
                  }
               }
            }
            else
            {
               // successor finished
               if (relation.getLag().getDuration() == 0)
               {
                  earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
                  }
                  else
                  {
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
                  }
               }
            }
         }
      }
      else
      {
         // Predecessor started
         if (predecessorTask.getActualFinish() != null)
         {
            // Predecessor finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               if (relation.getLag().getDuration() == 0)
               {
                  earlyStart = predecessorTask.getEarlyFinish();
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     double actualLagDurationInHours = predecessorTask.getActualFinish().isAfter(m_dataDate) ? 0 : m_dateCalculator.getLagCalendar(relation).getWork(predecessorTask.getActualFinish(), m_dataDate, TimeUnit.HOURS).getDuration();
                     double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();
                     if (lagDurationInHours > actualLagDurationInHours)
                     {
                        Duration remainingLag = Duration.getInstance(lagDurationInHours - actualLagDurationInHours, TimeUnit.HOURS);
                        earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish(), remainingLag);
                     }
                     else
                     {
                        earlyStart = predecessorTask.getEarlyFinish();
                     }
                  }
                  else
                  {
                     earlyStart = predecessorTask.getEarlyFinish();
                  }
               }
            }
            else
            {
               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // successor not finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     earlyStart = predecessorTask.getEarlyFinish();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        double actualLagDurationInHours = predecessorTask.getActualFinish().isAfter(m_dataDate) ? 0 : m_dateCalculator.getLagCalendar(relation).getWork(predecessorTask.getActualFinish(), m_dataDate, TimeUnit.HOURS).getDuration();
                        double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();
                        if (lagDurationInHours > actualLagDurationInHours)
                        {
                           Duration remainingLag = Duration.getInstance(lagDurationInHours - actualLagDurationInHours, TimeUnit.HOURS);
                           earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish(), remainingLag);
                        }
                        else
                        {
                           earlyStart = predecessorTask.getEarlyFinish();
                        }
                     }
                     else
                     {
                        earlyStart = predecessorTask.getEarlyFinish();
                     }
                  }
               }
               else
               {
                  // successor finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     earlyStart = predecessorTask.getEarlyFinish();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        earlyStart = predecessorTask.getEarlyFinish();
                     }
                     else
                     {
                        earlyStart = predecessorTask.getEarlyFinish();
                     }
                  }
               }
            }
         }
         else
         {
            // Predecessor not finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               if (relation.getLag().getDuration() == 0)
               {
                  earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
                  }
                  else
                  {
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
                  }
               }
            }
            else
            {
               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // successor not finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
                     }
                     else
                     {
                        earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
                     }
                  }
               }
               else
               {
                  // successor finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
                     }
                     else
                     {
                        earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
                     }
                  }
               }
            }
         }
      }

      return earlyStart;
   }

   /**
    * Calculate the early start for the successor task in a start-start relationship.
    *
    * @param relation relationship between two tasks
    * @return calculated early start date
    */
   private LocalDateTime calculateEarlyStartForStartStart(Relation relation)
   {
      Task predecessorTask = relation.getPredecessorTask();
      Task successorTask = relation.getSuccessorTask();
      LocalDateTime earlyStart;

      if (predecessorTask.getActualStart() == null)
      {
         // Predecessor not started
         if (successorTask.getActualStart() == null)
         {
            // Successor not started
            if (relation.getLag().getDuration() == 0)
            {
               // why adjust the next work start with the lag calendar? not sure, but it seems to work ;-)
               earlyStart = m_dateCalculator.getLagCalendar(relation).getNextWorkStart(predecessorTask.getEarlyStart());
            }
            else
            {
               if (relation.getLag().getDuration() > 0)
               {
                  earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart());
               }
               else
               {
                  earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart());
               }
            }
         }
         else
         {
            // successor started
            if (successorTask.getActualFinish() == null)
            {
               // successor not finished
               if (relation.getLag().getDuration() == 0)
               {
                  earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart());
                  }
                  else
                  {
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart());
                  }
               }
            }
            else
            {
               // successor finished
               if (relation.getLag().getDuration() == 0)
               {
                  earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart());
                  }
                  else
                  {
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart());
                  }
               }
            }
         }
      }
      else
      {
         // Predecessor started
         if (predecessorTask.getActualFinish() != null)
         {
            // Predecessor finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               if (relation.getLag().getDuration() == 0)
               {
                  earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getActualStart());
                  if (earlyStart.isBefore(m_dataDate))
                  {
                     earlyStart = predecessorTask.getEarlyStart();
                  }
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getActualStart());
                     if (earlyStart.isBefore(m_dataDate))
                     {
                        earlyStart = predecessorTask.getEarlyStart();
                     }
                  }
                  else
                  {
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getActualStart());
                     if (!earlyStart.isAfter(m_dataDate))
                     {
                        earlyStart = predecessorTask.getEarlyStart();
                     }
                  }
               }
            }
            else
            {
               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // successor not finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     earlyStart = predecessorTask.getEarlyStart();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getActualStart());
                        if (earlyStart.isBefore(m_dataDate))
                        {
                           earlyStart = predecessorTask.getEarlyStart();
                        }
                     }
                     else
                     {
                        earlyStart = predecessorTask.getEarlyStart();
                     }
                  }
               }
               else
               {
                  // successor finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     earlyStart = predecessorTask.getEarlyStart();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        earlyStart = predecessorTask.getEarlyStart();
                     }
                     else
                     {
                        earlyStart = predecessorTask.getEarlyStart();
                     }
                  }
               }
            }
         }
         else
         {
            // Predecessor not finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();
               double actualDurationInHours = predecessorTask.getActualDuration().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();

               if (actualDurationInHours == 0 || lagDurationInHours <= 0.0)
               {
                  // We have a milestone, or we have no positive lag
                  earlyStart = predecessorTask.getEarlyStart();
               }
               else
               {
                  if (actualDurationInHours >= lagDurationInHours)
                  {
                     // We have progressed more than the lag
                     earlyStart = predecessorTask.getEarlyStart();
                  }
                  else
                  {
                     // We still need to account for some or all of the lag
                     Duration remainingLag = Duration.getInstance(lagDurationInHours - actualDurationInHours, TimeUnit.HOURS);
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart(), remainingLag);
                  }
               }
            }
            else
            {
               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // successor not finished
                  double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();
                  if (lagDurationInHours <= 0.0)
                  {
                     // We have no positive lag
                     earlyStart = predecessorTask.getEarlyStart();
                  }
                  else
                  {
                     double actualDurationInHours = predecessorTask.getActualDuration().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();
                     if (actualDurationInHours >= lagDurationInHours)
                     {
                        // We have progressed more than the lag
                        earlyStart = predecessorTask.getEarlyStart();
                     }
                     else
                     {
                        // We still need to account for some or all of the lag
                        Duration remainingLag = Duration.getInstance(lagDurationInHours - actualDurationInHours, TimeUnit.HOURS);
                        earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart(), remainingLag);
                     }
                  }
               }
               else
               {
                  // successor finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     earlyStart = predecessorTask.getEarlyStart();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        earlyStart = predecessorTask.getEarlyStart();
                     }
                     else
                     {
                        earlyStart = predecessorTask.getEarlyStart();
                     }
                  }
               }
            }
         }
      }

      return earlyStart;
   }

   /**
    * Calculate the early start for the successor task in a finish-finish relationship.
    *
    * @param relation relationship between two tasks
    * @return calculated early start date
    */
   private DrivingRelation calculateEarlyStartForFinishFinish(Relation relation)
   {
      Task predecessorTask = relation.getPredecessorTask();
      Task successorTask = relation.getSuccessorTask();
      LocalDateTime earlyStart;
      LocalDateTime appliedEarlyFinish = null;

      if (predecessorTask.getActualStart() == null)
      {
         // Predecessor not started
         if (successorTask.getActualStart() == null)
         {
            // Successor not started
            if (relation.getLag().getDuration() == 0)
            {
               appliedEarlyFinish = predecessorTask.getEarlyFinish();
               if (!isWorkingTime(successorTask, appliedEarlyFinish))
               {
                  appliedEarlyFinish = getEquivalentNextWorkStart(successorTask, appliedEarlyFinish);
               }
               earlyStart = getDateFromFinishAndRemainingDuration(successorTask, predecessorTask.getEarlyFinish());
            }
            else
            {
               if (relation.getLag().getDuration() > 0)
               {
                  earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish()));
               }
               else
               {
                  appliedEarlyFinish = m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish());
                  earlyStart = getDateFromFinishAndRemainingDuration(successorTask, appliedEarlyFinish);
               }
            }
         }
         else
         {
            // successor started
            if (successorTask.getActualFinish() == null)
            {
               // successor not finished
               if (relation.getLag().getDuration() == 0)
               {
                  earlyStart = getDateFromFinishAndRemainingDuration(successorTask, predecessorTask.getEarlyFinish());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish()));
                  }
                  else
                  {
                     earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish()));
                  }
               }
            }
            else
            {
               // successor finished
               if (relation.getLag().getDuration() == 0)
               {
                  earlyStart = getDateFromFinishAndRemainingDuration(successorTask, predecessorTask.getEarlyFinish());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish()));
                  }
                  else
                  {
                     earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish()));
                  }
               }
            }
         }
      }
      else
      {
         // Predecessor started
         if (predecessorTask.getActualFinish() != null)
         {
            // Predecessor finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               if (relation.getLag().getDuration() == 0.0)
               {
                  // P6 carries an unfinished predecessor's dates through a completed activity (retained logic):
                  // the predecessor's early finish holds them, its actual finish does not.
                  earlyStart = getDateFromFinishAndRemainingDuration(successorTask, predecessorTask.getEarlyFinish());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0.0)
                  {
                     double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();
                     double actualDurationInHours = predecessorTask.getActualDuration().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();
                     if (lagDurationInHours > actualDurationInHours)
                     {
                        earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, predecessorTask.getActualFinish()));
                     }
                     else
                     {
                        earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish())));
                     }
                  }
                  else
                  {
                     earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish())));
                  }
               }
            }
            else
            {
               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // successor not finished
                  if (relation.getLag().getDuration() == 0.0)
                  {
                     earlyStart = getDateFromFinishAndRemainingDuration(successorTask, predecessorTask.getActualFinish());
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0.0)
                     {
                        earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, predecessorTask.getActualFinish()));
                     }
                     else
                     {
                        earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, predecessorTask.getActualFinish()));
                     }
                  }
               }
               else
               {
                  // successor finished
                  if (relation.getLag().getDuration() == 0.0)
                  {
                     earlyStart = predecessorTask.getEarlyFinish();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0.0)
                     {
                        earlyStart = predecessorTask.getEarlyFinish();
                     }
                     else
                     {
                        earlyStart = predecessorTask.getEarlyFinish();
                     }
                  }
               }
            }
         }
         else
         {
            // Predecessor not finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               if (relation.getLag().getDuration() == 0.0)
               {
                  earlyStart = getDateFromFinishAndRemainingDuration(successorTask, predecessorTask.getEarlyFinish());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0.0)
                  {
                     earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish()));
                  }
                  else
                  {
                     earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish()));
                  }
               }
            }
            else
            {
               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // successor not finished
                  if (relation.getLag().getDuration() == 0.0)
                  {
                     earlyStart = getDateFromFinishAndRemainingDuration(successorTask, predecessorTask.getEarlyFinish());
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0.0)
                     {
                        earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish()));
                     }
                     else
                     {
                        earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish()));
                     }
                  }
               }
               else
               {
                  // successor finished
                  if (relation.getLag().getDuration() == 0.0)
                  {
                     earlyStart = getDateFromFinishAndRemainingDuration(successorTask, predecessorTask.getEarlyFinish());
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0.0)
                     {
                        earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish()));
                     }
                     else
                     {
                        earlyStart = getDateFromFinishAndRemainingDuration(successorTask, m_dateCalculator.addLag(relation, predecessorTask.getEarlyFinish()));
                     }
                  }
               }
            }
         }
      }
      
      return new DrivingRelation(relation, earlyStart, appliedEarlyFinish);
   }

   /**
    * Calculate the early start for the successor task in a start-finish relationship.
    *
    * @param relation relationship between two tasks
    * @return calculated early start date
    */
   private DrivingRelation calculateEarlyStartForStartFinish(Relation relation)
   {
      Task predecessorTask = relation.getPredecessorTask();
      Task successorTask = relation.getSuccessorTask();
      LocalDateTime earlyStart;
      LocalDateTime appliedEarlyFinish = null;

      if (predecessorTask.getActualStart() == null)
      {
         // Predecessor not started
         if (successorTask.getActualStart() == null)
         {
            // Successor not started
            if (relation.getLag().getDuration() == 0)
            {
               earlyStart = m_dateCalculator.addLag(relation, getDateFromFinishAndDuration(successorTask, predecessorTask.getEarlyStart()));
            }
            else
            {
               earlyStart = m_dateCalculator.addLag(relation, getDateFromFinishAndDuration(successorTask, predecessorTask.getEarlyStart()));
               if (earlyStart.isAfter(m_dataDate))
               {
                  appliedEarlyFinish = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart());
               }
            }
         }
         else
         {
            // successor started
            if (successorTask.getActualFinish() == null)
            {
               // successor not finished
               if (relation.getLag().getDuration() <= 0)
               {
                  LocalDateTime earlyFinish = getDateFromStartAndDuration(successorTask, successorTask.getActualStart());
                  earlyStart = getDateFromFinishAndRemainingDuration(successorTask, earlyFinish);
               }
               else
               {
                  LocalDateTime earlyFinish = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart());
                  earlyStart = getDateFromFinishAndRemainingDuration(successorTask, earlyFinish);
               }
            }
            else
            {
               // successor finished
               if (relation.getLag().getDuration() == 0)
               {
                  earlyStart = predecessorTask.getEarlyStart();
               }
               else
               {
                  earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart());
               }
            }
         }
      }
      else
      {
         // Predecessor started
         if (predecessorTask.getActualFinish() != null)
         {
            // Predecessor finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               if (relation.getLag().getDuration() == 0)
               {
                  earlyStart = m_dateCalculator.addLag(relation, getDateFromFinishAndDuration(successorTask, predecessorTask.getEarlyStart()));
               }
               else
               {
                  earlyStart = m_dateCalculator.addLag(relation, getDateFromFinishAndDuration(successorTask, predecessorTask.getEarlyStart()));
               }
            }
            else
            {
               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // successor not finished
                  double actualLagDurationInHours = predecessorTask.getActualStart().isAfter(m_dataDate) ? 0 : m_dateCalculator.getLagCalendar(relation).getWork(predecessorTask.getActualStart(), m_dataDate, TimeUnit.HOURS).getDuration();
                  double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();

                  if (lagDurationInHours > actualLagDurationInHours)
                  {
                     Duration remainingLag = Duration.getInstance(lagDurationInHours - actualLagDurationInHours, TimeUnit.HOURS);
                     LocalDateTime earlyFinish = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart(), remainingLag);
                     earlyStart = getDateFromFinishAndRemainingDuration(successorTask, earlyFinish);
                  }
                  else
                  {
                     earlyStart = predecessorTask.getEarlyStart();
                  }
               }
               else
               {
                  // successor finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     earlyStart = predecessorTask.getEarlyStart();
                  }
                  else
                  {
                     earlyStart = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart());
                     if (earlyStart.isAfter(m_dataDate))
                     {
                        earlyStart = m_dataDate;
                     }
                  }
               }
            }
         }
         else
         {
            // Predecessor not finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               if (relation.getLag().getDuration() == 0)
               {
                  earlyStart = m_dateCalculator.addLag(relation, getDateFromFinishAndDuration(successorTask, predecessorTask.getEarlyStart()));
                  if (earlyStart.isAfter(m_dataDate))
                  {
                     earlyStart = m_dataDate;
                  }
               }
               else
               {
                  earlyStart = m_dateCalculator.addLag(relation, getDateFromFinishAndDuration(successorTask, predecessorTask.getEarlyStart()));
                  if (earlyStart.isAfter(m_dataDate))
                  {
                     earlyStart = m_dataDate;
                  }
               }
            }
            else
            {
               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // successor not finished
                  double actualLagDurationInHours = predecessorTask.getActualStart().isAfter(m_dataDate) ? 0 : m_dateCalculator.getLagCalendar(relation).getWork(predecessorTask.getActualStart(), m_dataDate, TimeUnit.HOURS).getDuration();
                  double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();

                  if (lagDurationInHours > actualLagDurationInHours)
                  {
                     Duration remainingLag = Duration.getInstance(lagDurationInHours - actualLagDurationInHours, TimeUnit.HOURS);
                     LocalDateTime earlyFinish = m_dateCalculator.addLag(relation, predecessorTask.getEarlyStart(), remainingLag);
                     earlyStart = getDateFromFinishAndRemainingDuration(successorTask, earlyFinish);
                  }
                  else
                  {
                     earlyStart = predecessorTask.getEarlyStart();
                  }
               }
               else
               {
                  if (relation.getLag().getDuration() == 0)
                  {
                     // successor finished
                     earlyStart = predecessorTask.getEarlyStart();
                  }
                  else
                  {
                     // successor finished
                     earlyStart = getEquivalentNextWorkStart(successorTask, m_dataDate);
                  }
               }
            }
         }
      }

      return new DrivingRelation(relation, earlyStart, appliedEarlyFinish);
   }

   /**
    * Calculate the late finish for the predecessor task in this relationship.
    *
    * @param relation relationship between two tasks
    * @return calculated late finish date
    */
   private DrivingRelation calculateLateFinish(Relation relation)
   {
      switch (relation.getType())
      {
         case START_START:
         {
            return calculateLateFinishForStartStart(relation);
         }

         case FINISH_FINISH:
         {
            return calculateLateFinishForFinishFinish(relation);
         }

         case START_FINISH:
         {
            return calculateLateFinishForStartFinish(relation);
         }

         case FINISH_START:
         {
            return calculateLateFinishForFinishStart(relation);
         }

         default:
         {
            throw new UnsupportedOperationException();
         }
      }
   }

   /**
    * Ensure a late finish date is before the project finish date, and adjust if required.
    *
    * @param relation parent relation
    * @param lateFinish late finish date
    * @return late finish
    */
   private LocalDateTime adjustLateFinish(Relation relation, LocalDateTime lateFinish)
   {
      if (lateFinish.isAfter(m_backwardPassFinishDate))
      {
         // If we're between working periods, move back to the last work finish
         lateFinish = getEquivalentPreviousWorkFinish(relation.getPredecessorTask(), m_backwardPassFinishDate);
      }

      return lateFinish;
   }

   /**
    * Calculate the late finish for the predecessor task in a start-start relationship.
    *
    * @param relation relationship between two tasks
    * @return calculated late finish date
    */
   private DrivingRelation calculateLateFinishForStartStart(Relation relation)
   {
      Task predecessorTask = relation.getPredecessorTask();
      Task successorTask = relation.getSuccessorTask();
      LocalDateTime lateFinish = null;

      LocalDateTime lateStart;
      LocalDateTime appliedLateStart = null;

      if (predecessorTask.getActualStart() == null)
      {
         // Predecessor not started
         if (successorTask.getActualStart() == null)
         {
            // Successor not started
            if (relation.getLag().getDuration() == 0)
            {
               if (isWorkingTime(predecessorTask, successorTask.getLateStart()))
               {
                  lateStart = successorTask.getLateStart();
               }
               else
               {
                  lateStart = getNearestEquivalentDate(predecessorTask, successorTask.getLateStart());
               }

               appliedLateStart = lateStart;
               lateFinish = getDateFromStartAndRemainingDuration(predecessorTask, lateStart);
            }
            else
            {
               if (relation.getLag().getDuration() > 0)
               {
                  lateStart = getNextWorkStart(predecessorTask, m_dateCalculator.removeLag(relation, successorTask.getLateStart()));
                  lateFinish = getDateFromStartAndRemainingDuration(predecessorTask, lateStart);
               }
               else
               {
                  appliedLateStart = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                  lateStart = getNextWorkStart(predecessorTask, appliedLateStart);
                  lateFinish = getDateFromStartAndRemainingDuration(predecessorTask, lateStart);
               }
            }
         }
         else
         {
            // successor started
            if (!isComplete(successorTask))
            {
               // successor not finished
               if (relation.getLag().getDuration() == 0)
               {
                  lateStart = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     lateStart = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                  }
                  else
                  {
                     lateStart = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                  }
               }
            }
            else
            {
               // successor finished
               if (relation.getLag().getDuration() == 0)
               {
                  //appliedLateStart = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                  lateStart = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     lateStart = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                  }
                  else
                  {
                     lateStart = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                  }
               }
            }
         }
      }
      else
      {
         // Predecessor Started
         if (isComplete(predecessorTask))
         {
            // Predecessor finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               if (relation.getLag().getDuration() == 0)
               {
                  // appliedLateStart = successorTask.getLateStart();
                  lateStart = successorTask.getLateStart();
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     double actualLagDurationInHours = predecessorTask.getActualStart().isAfter(m_dataDate) ? 0 : m_dateCalculator.getLagCalendar(relation).getWork(predecessorTask.getActualStart(), m_dataDate, TimeUnit.HOURS).getDuration();
                     double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();

                     if (lagDurationInHours > actualLagDurationInHours)
                     {
                        Duration remainingLag = Duration.getInstance(lagDurationInHours - actualLagDurationInHours, TimeUnit.HOURS);
                        lateStart = m_dateCalculator.removeLag(relation, successorTask.getLateStart(), remainingLag);
                     }
                     else
                     {
                        lateStart = successorTask.getLateStart();
                     }
                  }
                  else
                  {
                     lateStart = successorTask.getLateStart();
                  }
               }
            }
            else
            {
               // successor started
               if (!isComplete(successorTask))
               {
                  // successor not finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     lateStart = successorTask.getLateStart();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        lateStart = successorTask.getLateStart();
                     }
                     else
                     {
                        lateStart = successorTask.getLateStart();
                     }
                  }
               }
               else
               {
                  // successor finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     lateStart = successorTask.getLateStart();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        double actualLagDurationInHours = predecessorTask.getActualStart().isAfter(m_dataDate) ? 0 : m_dateCalculator.getLagCalendar(relation).getWork(predecessorTask.getActualStart(), m_dataDate, TimeUnit.HOURS).getDuration();
                        double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();

                        if (lagDurationInHours > actualLagDurationInHours)
                        {
                           Duration remainingLag = Duration.getInstance(lagDurationInHours - actualLagDurationInHours, TimeUnit.HOURS);
                           lateStart = m_dateCalculator.removeLag(relation, successorTask.getLateStart(), remainingLag);
                        }
                        else
                        {
                           lateStart = successorTask.getLateStart();
                        }
                     }
                     else
                     {
                        lateStart = successorTask.getLateStart();
                     }
                  }
               }
            }
         }
         else
         {
            // Predecessor not finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               if (relation.getLag().getDuration() == 0)
               {
                  lateStart = successorTask.getLateStart();
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     double actualDurationInHours = predecessorTask.getActualDuration().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();
                     double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();

                     if (actualDurationInHours >= lagDurationInHours)
                     {
                        lateStart = successorTask.getLateStart();
                     }
                     else
                     {
                        Duration remainingLag = Duration.getInstance(lagDurationInHours - actualDurationInHours, TimeUnit.HOURS);
                        lateStart = m_dateCalculator.removeLag(relation, successorTask.getLateStart(), remainingLag);
                     }
                  }
                  else
                  {
                     lateStart = successorTask.getLateStart();
                  }
               }
            }
            else
            {
               // successor started
               if (!isComplete(successorTask))
               {
                  // successor not finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     lateStart = successorTask.getLateStart();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        double actualDurationInHours = predecessorTask.getActualDuration().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();
                        double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();

                        if (actualDurationInHours >= lagDurationInHours)
                        {
                           appliedLateStart = successorTask.getLateStart();
                           lateStart = successorTask.getLateStart();
                        }
                        else
                        {
                           Duration remainingLag = Duration.getInstance(lagDurationInHours - actualDurationInHours, TimeUnit.HOURS);
                           lateStart = m_dateCalculator.removeLag(relation, successorTask.getLateStart(), remainingLag);
                        }
                     }
                     else
                     {
                        lateStart = successorTask.getLateStart();
                     }
                  }
               }
               else
               {
                  // successor finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     appliedLateStart = successorTask.getLateStart();
                     lateStart = successorTask.getLateStart();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        appliedLateStart = successorTask.getLateStart();
                        lateStart = successorTask.getLateStart();
                     }
                     else
                     {
                        lateStart = successorTask.getLateStart();
                     }
                  }
               }
            }
         }
      }

      if (lateFinish == null)
      {
         lateFinish = getDateFromStartAndRemainingDuration(predecessorTask, lateStart);
      }

      return new DrivingRelation(relation, appliedLateStart, lateFinish);
   }

   /**
    * Returns true if an activity is complete.
    *
    * @param task  target activity
    * @return true if the activity is complete
    */
   private boolean isComplete(Task task)
   {
      if (task.getActualFinish() != null)
      {
         return true;
      }

      ActivityType type = task.getActivityType();
      return type != ActivityType.START_MILESTONE && type != ActivityType.FINISH_MILESTONE && task.getRemainingDuration().getDuration() == 0;
   }

   /**
    * Calculate the late finish for the predecessor task in a finish-finish relationship.
    *
    * @param relation relationship between two tasks
    * @return calculated late finish date
    */
   private DrivingRelation calculateLateFinishForFinishFinish(Relation relation)
   {
      Task predecessorTask = relation.getPredecessorTask();
      Task successorTask = relation.getSuccessorTask();
      LocalDateTime lateFinish;

      if (predecessorTask.getActualStart() == null)
      {
         // Predecessor not started
         if (successorTask.getActualStart() == null)
         {
            // Successor not started
            if (relation.getLag().getDuration() == 0)
            {
               lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
            }
            else
            {
               if (relation.getLag().getDuration() > 0)
               {
                  lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
               }
               else
               {
                  lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
               }
            }
         }
         else
         {
            // successor started
            if (successorTask.getActualFinish() == null)
            {
               // successor not finished
               if (relation.getLag().getDuration() == 0)
               {
                  lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
                  }
                  else
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
                  }
               }
            }
            else
            {
               // successor finished
               if (relation.getLag().getDuration() == 0)
               {
                  lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
                  }
                  else
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
                  }
               }
            }
         }
      }
      else
      {
         // Predecessor Started
         if (predecessorTask.getActualFinish() != null)
         {
            // Predecessor finished
            if (successorTask.getActualStart() == null)
            {
               if (relation.getLag().getDuration() == 0)
               {
                  lateFinish = successorTask.getLateFinish();
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     // Successor not started
                     double actualLagDurationInHours = predecessorTask.getActualFinish().isAfter(m_dataDate) ? 0 : m_dateCalculator.getLagCalendar(relation).getWork(predecessorTask.getActualFinish(), m_dataDate, TimeUnit.HOURS).getDuration();
                     double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();

                     if (lagDurationInHours > actualLagDurationInHours)
                     {
                        Duration remainingLag = Duration.getInstance(lagDurationInHours - actualLagDurationInHours, TimeUnit.HOURS);
                        lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish(), remainingLag);
                     }
                     else
                     {
                        lateFinish = successorTask.getLateFinish();
                     }
                  }
                  else
                  {
                     lateFinish = successorTask.getLateFinish();
                  }
               }
            }
            else
            {
               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // successor not finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     lateFinish = successorTask.getLateFinish();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        lateFinish = successorTask.getLateFinish();
                     }
                     else
                     {
                        lateFinish = successorTask.getLateFinish();
                     }
                  }
               }
               else
               {
                  // successor finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     lateFinish = successorTask.getLateFinish();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        double actualLagDurationInHours = predecessorTask.getActualFinish().isAfter(m_dataDate) ? 0 : m_dateCalculator.getLagCalendar(relation).getWork(predecessorTask.getActualFinish(), m_dataDate, TimeUnit.HOURS).getDuration();
                        double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();

                        if (lagDurationInHours > actualLagDurationInHours)
                        {
                           Duration remainingLag = Duration.getInstance(lagDurationInHours - actualLagDurationInHours, TimeUnit.HOURS);
                           lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish(), remainingLag);
                        }
                        else
                        {
                           lateFinish = successorTask.getLateFinish();
                        }
                     }
                     else
                     {
                        lateFinish = successorTask.getLateFinish();
                     }
                  }
               }
            }
         }
         else
         {
            // Predecessor not finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               if (relation.getLag().getDuration() == 0)
               {
                  lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
                  }
                  else
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
                  }
               }
            }
            else
            {
               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // successor not finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
                     }
                     else
                     {
                        lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
                     }
                  }
               }
               else
               {
                  // successor finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
                     }
                     else
                     {
                        lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
                     }
                  }
               }
            }
         }
      }

      return new DrivingRelation(relation, null, lateFinish);
   }

   /**
    * Calculate the late finish for the predecessor task in a start-finish relationship.
    *
    * @param relation relationship between two tasks
    * @return calculated late finish date
    */
   private DrivingRelation calculateLateFinishForStartFinish(Relation relation)
   {
      Task predecessorTask = relation.getPredecessorTask();
      Task successorTask = relation.getSuccessorTask();
      LocalDateTime lateFinish;
      LocalDateTime lateStart = null;

      if (predecessorTask.getActualStart() == null)
      {
         // Predecessor not started
         if (successorTask.getActualStart() == null)
         {
            // Successor not started
            if (relation.getLag().getDuration() == 0)
            {
               lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
            }
            else
            {
               if (relation.getLag().getDuration() > 0)
               {
                  lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
               }
               else
               {
                  lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
               }
            }
         }
         else
         {
            // successor started
            if (successorTask.getActualFinish() == null)
            {
               // successor not finished
               if (relation.getLag().getDuration() == 0)
               {
                  lateStart = successorTask.getLateFinish();
                  lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, lateStart));
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
                  }
                  else
                  {
                     lateStart = m_dateCalculator.removeLag(relation, successorTask.getLateFinish());
                     lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
                  }
               }
            }
            else
            {
               // successor finished
               if (relation.getLag().getDuration() == 0)
               {
                  lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
                  }
                  else
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
                  }
               }
            }
         }
      }
      else
      {
         // Predecessor Started
         if (predecessorTask.getActualFinish() != null)
         {
            // Predecessor finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               if (relation.getLag().getDuration() == 0)
               {
                  lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
                  }
                  else
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
                  }
               }
            }
            else
            {
               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // successor not finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
                     }
                     else
                     {
                        lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
                     }
                  }
               }
               else
               {
                  // successor finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     lateFinish = successorTask.getLateFinish();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        lateFinish = successorTask.getLateFinish();
                     }
                     else
                     {
                        lateFinish = successorTask.getLateFinish();
                     }
                  }
               }
            }
         }
         else
         {
            // Predecessor not finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               if (relation.getLag().getDuration() == 0)
               {
                  lateFinish = getDateFromStartAndRemainingDuration(predecessorTask, successorTask.getLateFinish());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     lateStart = successorTask.getLateFinish();
                     lateFinish = getDateFromStartAndRemainingDuration(predecessorTask, lateStart);
                  }
                  else
                  {
                     lateFinish = getDateFromStartAndRemainingDuration(predecessorTask, successorTask.getLateFinish());
                  }
               }
            }
            else
            {
               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // successor not finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
                     }
                     else
                     {
                        lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()));
                     }
                  }
               }
               else
               {
                  // successor finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     lateFinish = getDateFromStartAndRemainingDuration(predecessorTask, successorTask.getLateFinish());
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        double actualLagDurationInHours = predecessorTask.getActualStart().isAfter(m_dataDate) ? 0 : m_dateCalculator.getLagCalendar(relation).getWork(predecessorTask.getActualStart(), m_dataDate, TimeUnit.HOURS).getDuration();
                        double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();

                        if (lagDurationInHours > actualLagDurationInHours)
                        {
                           Duration remainingLag = Duration.getInstance(lagDurationInHours - actualLagDurationInHours, TimeUnit.HOURS);
                           lateFinish = m_dateCalculator.removeLag(relation, getDateFromStartAndDuration(predecessorTask, successorTask.getLateFinish()), remainingLag);
                        }
                        else
                        {
                           lateFinish = getDateFromStartAndRemainingDuration(predecessorTask, successorTask.getLateFinish());
                        }
                     }
                     else
                     {
                        lateFinish = getDateFromStartAndRemainingDuration(predecessorTask, successorTask.getLateFinish());
                     }
                  }
               }
            }
         }
      }

      return new DrivingRelation(relation, lateStart, lateFinish);
   }

   /**
    * Calculate the late finish for the predecessor task in a finish-start relationship.
    *
    * @param relation relationship between two tasks
    * @return calculated late finish date
    */
   private DrivingRelation calculateLateFinishForFinishStart(Relation relation)
   {
      Task predecessorTask = relation.getPredecessorTask();
      Task successorTask = relation.getSuccessorTask();
      LocalDateTime lateFinish;

      if (predecessorTask.getActualStart() == null)
      {
         // Predecessor not started
         if (successorTask.getActualStart() == null)
         {
            // Successor not started
            if (relation.getLag().getDuration() == 0)
            {
               lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
               if (!isWorkingTime(predecessorTask, lateFinish))
               {
                  lateFinish = getEquivalentPreviousWorkFinish(predecessorTask, lateFinish);
               }
            }
            else
            {
               if (relation.getLag().getDuration() > 0)
               {
                  lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
               }
               else
               {
                  lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
               }
            }
         }
         else
         {
            // successor started
            if (successorTask.getActualFinish() == null)
            {
               // successor not finished
               if (relation.getLag().getDuration() == 0)
               {
                  lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                  }
                  else
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                  }
               }
            }
            else
            {
               // successor finished
               if (relation.getLag().getDuration() == 0)
               {
                  lateFinish = successorTask.getLateStart();
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     lateFinish = successorTask.getLateStart();
                  }
                  else
                  {
                     lateFinish = successorTask.getLateStart();
                  }
               }
            }
         }
      }
      else
      {
         // Predecessor Started
         if (predecessorTask.getActualFinish() != null)
         {
            // Predecessor finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               if (relation.getLag().getDuration() == 0)
               {
                  lateFinish = successorTask.getLateStart();
               }
               else
               {
                  if (relation.getLag().getDuration() > 0.0)
                  {
                     double actualLagDurationInHours = predecessorTask.getActualFinish().isAfter(m_dataDate) ? 0 : m_dateCalculator.getLagCalendar(relation).getWork(predecessorTask.getActualFinish(), m_dataDate, TimeUnit.HOURS).getDuration();
                     double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();

                     if (lagDurationInHours > actualLagDurationInHours)
                     {
                        Duration remainingLag = Duration.getInstance(lagDurationInHours - actualLagDurationInHours, TimeUnit.HOURS);
                        lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart(), remainingLag);
                     }
                     else
                     {
                        lateFinish = successorTask.getLateStart();
                     }
                  }
                  else
                  {
                     lateFinish = successorTask.getLateStart();
                  }
               }
            }
            else
            {
               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // check for actual progress
                  if (relation.getLag().getDuration() == 0)
                  {
                     lateFinish = successorTask.getLateStart();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        if (successorTask.getActualDuration().getDuration() == 0.0)
                        {
                           lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                        }
                        else
                        {
                           lateFinish = successorTask.getLateStart();
                        }
                     }
                     else
                     {
                        if (successorTask.getActualDuration().getDuration() == 0.0)
                        {
                           lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                        }
                        else
                        {
                           lateFinish = successorTask.getLateStart();
                        }
                     }
                  }
               }
               else
               {
                  // successor finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     lateFinish = successorTask.getLateStart();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        double actualLagDurationInHours = predecessorTask.getActualFinish().isAfter(m_dataDate) ? 0 : m_dateCalculator.getLagCalendar(relation).getWork(predecessorTask.getActualFinish(), m_dataDate, TimeUnit.HOURS).getDuration();
                        double lagDurationInHours = relation.getLag().convertUnits(TimeUnit.HOURS, m_file.getProjectProperties()).getDuration();

                        if (lagDurationInHours > actualLagDurationInHours)
                        {
                           Duration remainingLag = Duration.getInstance(lagDurationInHours - actualLagDurationInHours, TimeUnit.HOURS);
                           lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart(), remainingLag);
                        }
                        else
                        {
                           lateFinish = successorTask.getLateStart();
                        }
                     }
                     else
                     {
                        lateFinish = successorTask.getLateStart();
                     }
                  }
               }
            }
         }
         else
         {
            // Predecessor not finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               if (relation.getLag().getDuration() == 0)
               {
                  lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
               }
               else
               {
                  if (relation.getLag().getDuration() > 0)
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                  }
                  else
                  {
                     lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                  }
               }
            }
            else
            {
               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // check for actual progress
                  if (relation.getLag().getDuration() == 0)
                  {
                     if (successorTask.getActualDuration().getDuration() == 0.0)
                     {
                        lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                     }
                     else
                     {
                        lateFinish = successorTask.getLateStart();
                     }
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        if (successorTask.getActualDuration().getDuration() == 0.0)
                        {
                           lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                        }
                        else
                        {
                           lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                        }
                     }
                     else
                     {
                        if (successorTask.getActualDuration().getDuration() == 0.0)
                        {
                           lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                        }
                        else
                        {
                           // P6 removes a lead whatever the successor's progress
                           lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                        }
                     }
                  }
               }
               else
               {
                  // successor finished
                  if (relation.getLag().getDuration() == 0)
                  {
                     lateFinish = successorTask.getLateStart();
                  }
                  else
                  {
                     if (relation.getLag().getDuration() > 0)
                     {
                        lateFinish = successorTask.getLateStart();
                     }
                     else
                     {
                        // P6 removes the lead from a completed successor's late start, as it does for one not started
                        lateFinish = m_dateCalculator.removeLag(relation, successorTask.getLateStart());
                     }
                  }
               }
            }
         }
      }

      return new DrivingRelation(relation, null, lateFinish);
   }
   
   /**
    * Determine if the task's effective calendar should be used when scheduling.
    *
    * @param task task
    * @return true if effective calendar should be used
    */
   private boolean useTaskEffectiveCalendar(Task task)
   {
      return task.getActivityType() != ActivityType.RESOURCE_DEPENDENT || task.getResourceAssignments().stream().noneMatch(r -> r.getResource().getType().isTimeBased());
   }

   /**
    * Calculate a date from a start date plus the task duration.
    *
    * @param task parent task
    * @param date start date
    * @return start date plus task duration
    */
   private LocalDateTime getDateFromStartAndDuration(Task task, LocalDateTime date)
   {
      if (useTaskEffectiveCalendar(task))
      {
         return m_dateCalculator.getDate(task.getEffectiveCalendar(), date, task.getDuration());
      }

      return getDateFromStartAndWork(task, date);
   }

   /**
    * Find latest date by adding resource assignment work to a date.
    *
    * @param task parent task
    * @param date date
    * @return date plus work
    */
   private LocalDateTime getDateFromStartAndWork(Task task, LocalDateTime date)
   {
      return getResourceAssignmentStream(task).map(r -> getDateFromWork(r, date, r.getWork())).max(Comparator.naturalOrder()).orElseGet(null);
   }

   /**
    * Calculate a date from a finish date minus the task duration.
    *
    * @param task parent task
    * @param date finish date
    * @return finish date minus task duration
    */
   private LocalDateTime getDateFromFinishAndDuration(Task task, LocalDateTime date)
   {
      if (useTaskEffectiveCalendar(task))
      {
         return m_dateCalculator.getDate(task.getEffectiveCalendar(), date, task.getDuration().negate());
      }

      return getDateFromFinishAndWork(task, date);
   }

   /**
    * Find the earliest date by subtracting resource assignment work from a date.
    *
    * @param task parent task
    * @param date date
    * @return date less work
    */
   private LocalDateTime getDateFromFinishAndWork(Task task, LocalDateTime date)
   {
      return getResourceAssignmentStream(task).map(r -> getDateFromWork(r, date, r.getWork().negate())).min(Comparator.naturalOrder()).orElseGet(null);
   }

   /**
    * Calculate a date from a start date plus the task remaining duration.
    *
    * @param task parent task
    * @param date start date
    * @return start date plus task remaining duration
    */
   private LocalDateTime getDateFromStartAndRemainingDuration(Task task, LocalDateTime date)
   {
      if (useTaskEffectiveCalendar(task))
      {
         return m_dateCalculator.getDate(task.getEffectiveCalendar(), date, task.getRemainingDuration());
      }

      return getDateFromStartAndRemainingWork(task, date);
   }

   /**
    * Find latest date by adding resource assignment work to a date.
    *
    * @param task parent task
    * @param date date
    * @return date plus work
    */
   private LocalDateTime getDateFromStartAndRemainingWork(Task task, LocalDateTime date)
   {
      return getResourceAssignmentStream(task).map(r -> getDateFromWork(r, date, r.getRemainingWork())).max(Comparator.naturalOrder()).orElseGet(null);
   }

   /**
    * Calculate a date from a finish date minus the task remaining duration.
    *
    * @param task parent task
    * @param date finish date
    * @return finish date minus task remaining duration
    */
   private LocalDateTime getDateFromFinishAndRemainingDuration(Task task, LocalDateTime date)
   {
      if (useTaskEffectiveCalendar(task))
      {
         return m_dateCalculator.getDate(task.getEffectiveCalendar(), date, task.getRemainingDuration().negate());
      }

      return getDateFromFinishAndRemainingWork(task, date);
   }

   /**
    * Find the earliest date by subtracting resource assignment work from a date.
    *
    * @param task parent task
    * @param date date
    * @return date less work
    */
   private LocalDateTime getDateFromFinishAndRemainingWork(Task task, LocalDateTime date)
   {
      return getResourceAssignmentStream(task).map(r -> getDateFromWork(r, date, r.getRemainingWork().negate())).min(Comparator.naturalOrder()).orElseGet(null);
   }

   /**
    * Determine if the given MPXJ Task is a P6 Activity.
    *
    * @param task Task instance
    * @return true if this is a P6 Activity
    */
   static boolean isActivity(Task task)
   {
      return !(task.getSummary() || task.getActivityType() == ActivityType.LEVEL_OF_EFFORT || task.getActivityType() == ActivityType.WBS_SUMMARY);
   }

   /**
    * Determine if the given MPXJ Task is a P6 Level of Effort Activity.
    *
    * @param task Task instance
    * @return true if this is a P6 Level of Effort Activity
    */
   static boolean isLevelOfEffortActivity(Task task)
   {
      return task.getActivityType() == ActivityType.LEVEL_OF_EFFORT;
   }

   /**
    * Determine if the given MPXJ Task is a P6 WBS Summary Activity.
    *
    * @param task Task instance
    * @return true if this is a P6 WBS Summary Activity
    */
   static boolean isWbsSummary(Task task)
   {
      return task.getActivityType() == ActivityType.WBS_SUMMARY;
   }

   /**
    * Adjust Early Start and Early Finish dates for an activity with
    * an "As Late As Possible" constraint.
    *
    * @param task ALAP constrained task
    */
   private void alapAdjust(Task task) throws CpmException
   {
      LocalDateTime earlyStart;
      LocalDateTime earlyFinish;

      List<Relation> successors = task.getSuccessors().stream().filter(r -> isActivity(r.getSuccessorTask())).collect(Collectors.toList());
      if (successors.isEmpty())
      {
         earlyFinish = getEquivalentPreviousWorkFinish(task, m_forwardPassFinishDate);
         earlyStart = getDateFromFinishAndRemainingDuration(task, earlyFinish);
      }
      else
      {
         Relation relation = successors.stream().min(Comparator.comparing(this::getAlapEarlyStart)).orElseThrow(() -> new CpmException("Missing early start date"));
         earlyStart = getAlapEarlyStart(relation);

         if (task.getActualFinish() == null && task.getActivityType() == ActivityType.FINISH_MILESTONE)
         {
            earlyStart = getEquivalentPreviousWorkFinish(task, earlyStart);
         }
         earlyFinish = getDateFromStartAndRemainingDuration(task, earlyStart);

         Task successor = relation.getSuccessorTask();
         if (successor.getConstraintType() != ConstraintType.AS_LATE_AS_POSSIBLE || !successor.getSuccessors().isEmpty())
         {
            relation.setDriving(true);
         }
      }

      task.setEarlyStart(earlyStart);
      task.setEarlyFinish(earlyFinish);
      setRemainingEarlyDates(task);
      task.setDuration(calculateAtCompletionDuration(task));
   }

   /**
    * Calculate the ALAP Early Start from a relation's successor task.
    *
    * @param relation target relation
    * @return early start date
    */
   private LocalDateTime getAlapEarlyStart(Relation relation)
   {
      Task predecessorTask = relation.getPredecessorTask();
      Task successorTask = relation.getSuccessorTask();

      switch (relation.getType())
      {
         case START_START:
         {
            return getEquivalentNextWorkStart(predecessorTask, m_dateCalculator.removeLag(relation, successorTask.getEarlyStart()));
         }

         case FINISH_START:
         {
            if (predecessorTask.getActualStart() == null)
            {
               // Predecessor not started
               if (successorTask.getActualStart() == null)
               {
                  // Successor not started
                  LocalDateTime earlyStart = m_dateCalculator.removeLag(relation, getDateFromFinishAndRemainingDuration(predecessorTask, successorTask.getEarlyStart()));
                  if (!isWorkingTime(predecessorTask, earlyStart))
                  {
                     earlyStart = getEquivalentNextWorkStart(predecessorTask, earlyStart);
                  }
                  return earlyStart;
               }

               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // successor not finished
                  return m_dateCalculator.removeLag(relation, getDateFromFinishAndRemainingDuration(predecessorTask, successorTask.getEarlyStart()));
               }

               // successor finished
               return m_dateCalculator.removeLag(relation, getDateFromFinishAndRemainingDuration(predecessorTask, successorTask.getEarlyStart()));
            }

            // Predecessor Started
            if (predecessorTask.getActualFinish() == null)
            {
               // Predecessor not finished
               if (successorTask.getActualStart() == null)
               {
                  // Successor not started
                  return m_dateCalculator.removeLag(relation, getDateFromFinishAndRemainingDuration(predecessorTask, successorTask.getEarlyStart()));
               }

               // successor started
               if (successorTask.getActualFinish() == null)
               {
                  // successor not finished
                  return m_dateCalculator.removeLag(relation, getDateFromFinishAndRemainingDuration(predecessorTask, successorTask.getEarlyStart()));
               }

               // successor finished
               return m_dateCalculator.removeLag(relation, getDateFromFinishAndRemainingDuration(predecessorTask, successorTask.getEarlyStart()));
            }

            // Predecessor finished
            if (successorTask.getActualStart() == null)
            {
               // Successor not started
               return getEquivalentNextWorkStart(predecessorTask, m_dataDate);
               // But sometimes...
               // return m_dataDate;
            }

            // successor started
            if (successorTask.getActualFinish() == null)
            {
               // successor not finished
               return m_dataDate;
            }

            // successor finished
            return m_dataDate;
         }

         case FINISH_FINISH:
         {
            LocalDateTime earlyFinish = m_dateCalculator.removeLag(relation, successorTask.getEarlyFinish());
            return getDateFromFinishAndRemainingDuration(predecessorTask, earlyFinish);
         }

         case START_FINISH:
         {
            return getEquivalentNextWorkStart(predecessorTask, m_dateCalculator.removeLag(relation, successorTask.getEarlyFinish()));
         }

         default:
         {
            throw new UnsupportedOperationException();
         }
      }
   }

   /**
    * Populate the remaining early dates.
    *
    * @param task target task
    */
   private void setRemainingEarlyDates(Task task)
   {
      if (task.getActualFinish() != null)
      {
         return;
      }

      LocalDateTime remainingEarlyStart;
      LocalDateTime remainingEarlyFinish = null;

      if (task.getActualStart() == null)
      {
         remainingEarlyStart = task.getEarlyStart();
         remainingEarlyFinish = task.getEarlyFinish();
      }
      else
      {
         if (task.getActualDuration() != null && task.getActualDuration().getDuration() != 0)
         {
            remainingEarlyStart = task.getEarlyStart();
         }
         else
         {
            if ((task.getActualDuration() == null || task.getActualDuration().getDuration() == 0) || task.getActualStart().isAfter(m_dataDate))
            {
               remainingEarlyStart = task.getEarlyStart();
            }
            else
            {
               remainingEarlyStart = getNextWorkStart(task, m_dataDate);
            }
         }
      }

      if (remainingEarlyFinish == null)
      {
         remainingEarlyFinish = getDateFromStartAndRemainingDuration(task, remainingEarlyStart);
      }

      task.setRemainingEarlyStart(remainingEarlyStart);
      task.setRemainingEarlyFinish(remainingEarlyFinish);
   }

   /**
    * Populate the remaining late dates.
    *
    * @param task target task
    */
   private void setRemainingLateDates(Task task)
   {
      if (task.getActualFinish() != null)
      {
         return;
      }

      task.setRemainingLateStart(task.getLateStart());
      task.setRemainingLateFinish(task.getLateFinish());
   }

   /**
    * Clear dates ready to be repopulated.
    */
   private void clearDates()
   {
      for (Task task : m_file.getTasks())
      {
         task.setStart(null);
         task.setFinish(null);
         task.setEarlyStart(null);
         task.setEarlyFinish(null);
         task.setLateStart(null);
         task.setLateFinish(null);
         task.setRemainingEarlyStart(null);
         task.setRemainingEarlyFinish(null);
         task.setRemainingLateStart(null);
         task.setRemainingLateFinish(null);
         task.setLongestPath(false);

         // Clear fields to force recalculation
         task.set(TaskField.CRITICAL, null);
         task.set(TaskField.FREE_SLACK, null);
         task.set(TaskField.TOTAL_SLACK, null);
      }

      m_file.getRelations().forEach(r -> r.setDriving(false));

      // Force start and finish dates to be recalculated
      m_file.getProjectProperties().setStartDate(null);
      m_file.getProjectProperties().setFinishDate(null);
   }

   /**
    * Roll up dates to a WBS entity.
    *
    * @param parentTask parent WBS
    */
   private void rollupDates(Task parentTask)
   {
      // NOTE: LOE and WBS Summary are ignore at this point as they have null dates
      if (!parentTask.hasChildTasks())
      {
         return;
      }

      int finished = 0;
      LocalDateTime startDate = null;
      LocalDateTime finishDate = null;
      LocalDateTime plannedStartDate = null;
      LocalDateTime plannedFinishDate = null;
      LocalDateTime actualStartDate = null;
      LocalDateTime actualFinishDate = null;
      LocalDateTime earlyStartDate = null;
      LocalDateTime earlyFinishDate = null;
      LocalDateTime lateStartDate = null;
      LocalDateTime lateFinishDate = null;
      LocalDateTime baselineStartDate = null;
      LocalDateTime baselineFinishDate = null;
      LocalDateTime remainingEarlyStartDate = null;
      LocalDateTime remainingEarlyFinishDate = null;
      LocalDateTime remainingLateStartDate = null;
      LocalDateTime remainingLateFinishDate = null;
      boolean critical = false;

      for (Task task : parentTask.getChildTasks())
      {
         rollupDates(task);

         // the child tasks can have null dates (e.g. for nested wbs elements with no task children) so we
         // still must protect against some children having null dates

         startDate = LocalDateTimeHelper.min(startDate, task.getStart());
         finishDate = LocalDateTimeHelper.max(finishDate, task.getFinish());
         plannedStartDate = LocalDateTimeHelper.min(plannedStartDate, task.getPlannedStart());
         plannedFinishDate = LocalDateTimeHelper.max(plannedFinishDate, task.getPlannedFinish());
         actualStartDate = LocalDateTimeHelper.min(actualStartDate, task.getActualStart());
         actualFinishDate = LocalDateTimeHelper.max(actualFinishDate, task.getActualFinish());
         baselineStartDate = LocalDateTimeHelper.min(baselineStartDate, task.getBaselineStart());
         baselineFinishDate = LocalDateTimeHelper.max(baselineFinishDate, task.getBaselineFinish());

         if (task.getActivityType() != ActivityType.LEVEL_OF_EFFORT || task.getActualFinish() == null)
         {
            earlyStartDate = LocalDateTimeHelper.min(earlyStartDate, task.getEarlyStart());
            earlyFinishDate = LocalDateTimeHelper.max(earlyFinishDate, task.getEarlyFinish());
            remainingEarlyStartDate = LocalDateTimeHelper.min(remainingEarlyStartDate, task.getRemainingEarlyStart());
            remainingEarlyFinishDate = LocalDateTimeHelper.max(remainingEarlyFinishDate, task.getRemainingEarlyFinish());
            lateStartDate = LocalDateTimeHelper.min(lateStartDate, task.getLateStart());
            lateFinishDate = LocalDateTimeHelper.max(lateFinishDate, task.getLateFinish());
            remainingLateStartDate = LocalDateTimeHelper.min(remainingLateStartDate, task.getRemainingLateStart());
            remainingLateFinishDate = LocalDateTimeHelper.max(remainingLateFinishDate, task.getRemainingLateFinish());
         }

         if (task.getActualFinish() != null)
         {
            ++finished;
         }

         critical = critical || task.getCritical();
      }

      parentTask.setStart(startDate);
      parentTask.setFinish(finishDate);
      parentTask.setPlannedStart(plannedStartDate);
      parentTask.setPlannedFinish(plannedFinishDate);
      parentTask.setActualStart(actualStartDate);
      parentTask.setEarlyStart(earlyStartDate);
      parentTask.setEarlyFinish(earlyFinishDate);
      parentTask.setRemainingEarlyStart(remainingEarlyStartDate);
      parentTask.setRemainingEarlyFinish(remainingEarlyFinishDate);
      parentTask.setLateStart(lateStartDate);
      parentTask.setLateFinish(lateFinishDate);
      parentTask.setRemainingLateStart(remainingLateStartDate);
      parentTask.setRemainingLateFinish(remainingLateFinishDate);
      parentTask.setBaselineStart(baselineStartDate);
      parentTask.setBaselineFinish(baselineFinishDate);

      //
      // Only if all child tasks have actual finish dates do we
      // set the actual finish date on the parent task.
      //
      if (finished == parentTask.getChildTasks().size())
      {
         parentTask.setActualFinish(actualFinishDate);
      }

      Duration plannedDuration = null;
      if (plannedStartDate != null && plannedFinishDate != null)
      {
         plannedDuration = parentTask.getEffectiveCalendar().getWork(plannedStartDate, plannedFinishDate, TimeUnit.HOURS);
         parentTask.setPlannedDuration(plannedDuration);
      }

      Duration actualDuration = null;
      Duration remainingDuration = null;
      if (parentTask.getActualFinish() == null)
      {
         LocalDateTime taskStartDate = parentTask.getRemainingEarlyStart();
         if (taskStartDate == null)
         {
            taskStartDate = parentTask.getEarlyStart();
            if (taskStartDate == null)
            {
               taskStartDate = plannedStartDate;
            }
         }

         LocalDateTime taskFinishDate = parentTask.getRemainingEarlyFinish();
         if (taskFinishDate == null)
         {
            taskFinishDate = parentTask.getEarlyFinish();
            if (taskFinishDate == null)
            {
               taskFinishDate = plannedFinishDate;
            }
         }

         if (taskStartDate != null)
         {
            if (parentTask.getActualStart() != null)
            {
               actualDuration = parentTask.getEffectiveCalendar().getWork(parentTask.getActualStart(), taskStartDate, TimeUnit.HOURS);
            }

            if (taskFinishDate != null)
            {
               remainingDuration = parentTask.getEffectiveCalendar().getWork(taskStartDate, taskFinishDate, TimeUnit.HOURS);
            }
         }
      }
      else
      {
         actualDuration = parentTask.getEffectiveCalendar().getWork(parentTask.getActualStart(), parentTask.getActualFinish(), TimeUnit.HOURS);
         remainingDuration = Duration.getInstance(0, TimeUnit.HOURS);
      }

      if (actualDuration != null && actualDuration.getDuration() < 0)
      {
         actualDuration = null;
      }

      if (remainingDuration != null && remainingDuration.getDuration() < 0)
      {
         remainingDuration = null;
      }

      parentTask.setActualDuration(actualDuration);
      parentTask.setRemainingDuration(remainingDuration);
      parentTask.setDuration(Duration.add(actualDuration, remainingDuration, parentTask.getEffectiveCalendar()));

      if (plannedDuration != null && remainingDuration != null && plannedDuration.getDuration() != 0)
      {
         double durationPercentComplete = ((plannedDuration.getDuration() - remainingDuration.getDuration()) / plannedDuration.getDuration()) * 100.0;
         if (durationPercentComplete < 0)
         {
            durationPercentComplete = 0;
         }
         else
         {
            if (durationPercentComplete > 100)
            {
               durationPercentComplete = 100;
            }
         }
         parentTask.setPercentageComplete(Double.valueOf(durationPercentComplete));
         parentTask.setPercentCompleteType(PercentCompleteType.DURATION);
      }

      // Force total slack calculation to avoid overwriting the critical flag
      parentTask.getTotalSlack();
      parentTask.setCritical(critical);
   }

   private void levelOfEffortPass() throws CpmException
   {
      List<Task> activities = new DepthFirstGraphSort(m_file, PrimaveraScheduler::isLevelOfEffortActivity).sort();
      if (activities.isEmpty())
      {
         return;
      }

      for (Task activity : activities)
      {
         levelOfEffortPass(activity);
      }
   }

   /**
    * Schedule a Level of Effort activity.
    *
    * @param task target activity
    */
   private void levelOfEffortPass(Task task)
   {
      // We're assuming that once we have actuals, the LOE activity doesn't change.
      // We'll need to think about handling changes to actuals.
      if (task.getActualFinish() != null)
      {
         task.setStart(task.getActualStart());
         task.setFinish(task.getActualFinish());
         return;
      }

      List<AnnotatedDateTime> earlyStarts = new ArrayList<>();
      AnnotatedDateTime earlyFinishFromPredecessor = null;
      AnnotatedDateTime lateStartFromPredecessor = null;
      AnnotatedDateTime lateFinishFromPredecessor = null;

      for (Relation relation : task.getPredecessors())
      {
         Task predecessor = relation.getPredecessorTask();

         switch (relation.getType())
         {
            case START_START:
            {
               if (predecessor.getActualStart() == null)
               {
                  earlyStarts.add(AnnotatedDateTime.from(relation, m_dateCalculator.addLag(relation, predecessor.getEarlyStart())));
                  lateStartFromPredecessor = updateIfBefore(lateStartFromPredecessor, AnnotatedDateTime.from(relation, m_dateCalculator.addLag(relation, predecessor.getLateStart())));
               }
               else
               {
                  LocalDateTime start = m_dateCalculator.addLag(relation, predecessor.getActualStart());
                  if (isWorkingTime(task, start) && predecessor.getActualFinish() == null)
                  {
                     start = getEquivalentNextWorkStart(task, start);
                  }
                  earlyStarts.add(AnnotatedDateTime.fromActual(relation, start));
                  lateStartFromPredecessor = updateIfBefore(lateStartFromPredecessor, AnnotatedDateTime.from(relation, m_dateCalculator.addLag(relation, predecessor.getLateStart())));
               }
               break;
            }

            case FINISH_START:
            {
               if (predecessor.getActualFinish() == null)
               {
                  earlyStarts.add(AnnotatedDateTime.from(relation, m_dateCalculator.addLag(relation, predecessor.getEarlyFinish())));
                  lateStartFromPredecessor = updateIfBefore(lateStartFromPredecessor, AnnotatedDateTime.from(relation, m_dateCalculator.addLag(relation, predecessor.getLateFinish())));
               }
               else
               {
                  LocalDateTime candidateLateStart = predecessor.getActivityType() == ActivityType.START_MILESTONE ? predecessor.getLateStart() : predecessor.getActualFinish();
                  earlyStarts.add(AnnotatedDateTime.fromActual(relation, m_dateCalculator.addLag(relation, predecessor.getActualFinish())));
                  lateStartFromPredecessor = updateIfBefore(lateStartFromPredecessor, AnnotatedDateTime.fromActual(relation, m_dateCalculator.addLag(relation, candidateLateStart)));
               }
               break;
            }

            case START_FINISH:
            {
               if (predecessor.getActualStart() == null)
               {
                  earlyFinishFromPredecessor = updateIfAfter(earlyFinishFromPredecessor, AnnotatedDateTime.from(relation, adjustFinish(task, m_dateCalculator.addLag(relation, predecessor.getEarlyStart()))));
                  lateFinishFromPredecessor = updateIfAfter(lateFinishFromPredecessor, AnnotatedDateTime.from(relation, adjustFinish(task, m_dateCalculator.addLag(relation, predecessor.getLateStart()))));
               }
               else
               {
                  LocalDateTime finish = getEquivalentPreviousWorkFinish(task, m_dateCalculator.addLag(relation, predecessor.getActualStart()));
                  earlyFinishFromPredecessor = updateIfAfter(earlyFinishFromPredecessor, AnnotatedDateTime.fromActual(relation, finish));
                  lateFinishFromPredecessor = updateIfAfter(lateFinishFromPredecessor, AnnotatedDateTime.fromActual(relation, finish));
               }
               break;
            }

            case FINISH_FINISH:
            {
               if (predecessor.getActualFinish() == null)
               {
                  earlyFinishFromPredecessor = updateIfAfter(earlyFinishFromPredecessor, AnnotatedDateTime.from(relation, adjustFinish(task, m_dateCalculator.addLag(relation, predecessor.getEarlyFinish()))));
                  lateFinishFromPredecessor = updateIfAfter(lateFinishFromPredecessor, AnnotatedDateTime.from(relation, adjustFinish(task, m_dateCalculator.addLag(relation, predecessor.getLateFinish()))));
               }
               else
               {
                  earlyFinishFromPredecessor = updateIfAfter(earlyFinishFromPredecessor, AnnotatedDateTime.fromActual(relation, m_dateCalculator.addLag(relation, predecessor.getActualFinish())));
                  lateFinishFromPredecessor = updateIfAfter(lateFinishFromPredecessor, AnnotatedDateTime.fromActual(relation, m_dateCalculator.addLag(relation, predecessor.getActualFinish())));
               }
               break;
            }
         }
      }

      AnnotatedDateTime earlyFinishFromSuccessor = null;
      AnnotatedDateTime lateStartFromSuccessor = null;
      AnnotatedDateTime lateFinishFromSuccessor = null;

      for (Relation relation : task.getSuccessors())
      {
         Task successor = relation.getSuccessorTask();

         switch (relation.getType())
         {
            case START_START:
            {
               if (successor.getActualStart() == null)
               {
                  earlyStarts.add(AnnotatedDateTime.from(relation, m_dateCalculator.removeLag(relation, successor.getEarlyStart())));
                  lateStartFromSuccessor = updateIfBefore(lateStartFromSuccessor, AnnotatedDateTime.from(relation, m_dateCalculator.removeLag(relation, successor.getLateStart())));
               }
               else
               {
                  earlyStarts.add(AnnotatedDateTime.fromActual(relation, m_dateCalculator.removeLag(relation, successor.getActualStart())));
                  lateStartFromSuccessor = updateIfBefore(lateStartFromSuccessor, AnnotatedDateTime.fromActual(relation, m_dateCalculator.removeLag(relation, successor.getActualStart())));
               }
               break;
            }

            case FINISH_START:
            {
               if (successor.getActualStart() == null)
               {
                  earlyFinishFromSuccessor = updateIfAfter(earlyFinishFromSuccessor, AnnotatedDateTime.from(relation, adjustFinish(task, m_dateCalculator.removeLag(relation, successor.getEarlyStart()))));
                  lateFinishFromSuccessor = updateIfAfter(lateFinishFromSuccessor, AnnotatedDateTime.from(relation, adjustFinish(task, m_dateCalculator.removeLag(relation, successor.getLateStart()))));
               }
               else
               {
                  LocalDateTime finish = m_dateCalculator.removeLag(relation, successor.getActualStart());
                  if (isWorkingTime(task, finish))
                  {
                     finish = getEquivalentPreviousWorkFinish(task, finish);
                  }
                  earlyFinishFromSuccessor = updateIfAfter(earlyFinishFromSuccessor, AnnotatedDateTime.fromActual(relation, finish));
                  lateFinishFromSuccessor = updateIfAfter(lateFinishFromSuccessor, AnnotatedDateTime.fromActual(relation, finish));
               }
               break;
            }

            case START_FINISH:
            {
               if (successor.getActualFinish() == null)
               {
                  earlyStarts.add(AnnotatedDateTime.from(relation, m_dateCalculator.removeLag(relation, successor.getEarlyFinish())));
                  lateStartFromSuccessor = updateIfBefore(lateStartFromSuccessor, AnnotatedDateTime.from(relation, m_dateCalculator.removeLag(relation, successor.getLateFinish())));
               }
               else
               {
                  earlyStarts.add(AnnotatedDateTime.fromActual(relation, m_dateCalculator.removeLag(relation, successor.getActualFinish())));
                  lateStartFromSuccessor = updateIfBefore(lateStartFromSuccessor, AnnotatedDateTime.fromActual(relation, m_dateCalculator.removeLag(relation, successor.getActualFinish())));
               }
               break;
            }

            case FINISH_FINISH:
            {
               if (successor.getActualFinish() == null)
               {
                  earlyFinishFromSuccessor = updateIfAfter(earlyFinishFromSuccessor, AnnotatedDateTime.from(relation, adjustFinish(task, m_dateCalculator.removeLag(relation, successor.getEarlyFinish()))));
                  lateFinishFromSuccessor = updateIfAfter(lateFinishFromSuccessor, AnnotatedDateTime.from(relation, adjustFinish(task, m_dateCalculator.removeLag(relation, successor.getLateFinish()))));
               }
               else
               {
                  earlyFinishFromSuccessor = updateIfAfter(earlyFinishFromSuccessor, AnnotatedDateTime.fromActual(relation, m_dateCalculator.removeLag(relation, successor.getActualFinish())));
                  lateFinishFromSuccessor = updateIfAfter(lateFinishFromSuccessor, AnnotatedDateTime.fromActual(relation, m_dateCalculator.removeLag(relation, successor.getActualFinish())));
               }
               break;
            }
         }
      }

      AnnotatedDateTime earlyStart;
      if (earlyStarts.isEmpty())
      {
         earlyStart = AnnotatedDateTime.from(null, getNextWorkStart(task, m_dataDate));
      }
      else
      {
         LocalDateTime earliestDate = earlyStarts.stream().map(AnnotatedDateTime::getValue).min(Comparator.naturalOrder()).orElse(null);
         earlyStarts.removeIf(a -> !a.getValue().isEqual(earliestDate));
         earlyStart = earlyStarts.get(0);
      }

      AnnotatedDateTime earlyFinish;
      if (earlyFinishFromPredecessor == null && earlyFinishFromSuccessor == null)
      {
         earlyFinish = earlyStart;
      }
      else
      {
         if (earlyFinishFromPredecessor != null && earlyFinishFromSuccessor != null)
         {
            // Not correct: how do we determine which date to use?
            earlyFinish = earlyFinishFromSuccessor.isAfter(earlyFinishFromPredecessor) ? earlyFinishFromSuccessor : earlyFinishFromPredecessor;
         }
         else
         {
            earlyFinish = earlyFinishFromPredecessor == null ? earlyFinishFromSuccessor : earlyFinishFromPredecessor;
         }
      }

      AnnotatedDateTime lateFinish;
      if (lateFinishFromPredecessor == null && lateFinishFromSuccessor == null)
      {
         lateFinish = AnnotatedDateTime.from(null, m_forwardPassFinishDate);
      }
      else
      {
         if (lateFinishFromPredecessor != null && lateFinishFromSuccessor != null)
         {
            lateFinish = lateFinishFromSuccessor.isAfter(lateFinishFromPredecessor) ? lateFinishFromSuccessor : lateFinishFromPredecessor;
         }
         else
         {
            lateFinish = lateFinishFromPredecessor == null ? lateFinishFromSuccessor : lateFinishFromPredecessor;
         }
      }

      AnnotatedDateTime lateStart;
      if (lateStartFromPredecessor == null && lateStartFromSuccessor == null)
      {
         lateStart = lateFinish;
      }
      else
      {
         if (lateStartFromPredecessor != null && lateStartFromSuccessor != null)
         {
            lateStart = lateStartFromPredecessor.isBefore(lateStartFromSuccessor) ? lateStartFromPredecessor : lateStartFromSuccessor;
         }
         else
         {
            lateStart = lateStartFromPredecessor == null ? lateStartFromSuccessor : lateStartFromPredecessor;
         }
      }

      if (earlyStart == null || earlyFinish == null || lateStart == null || lateFinish == null)
      {
         return;
      }

      AnnotatedDateTime start = earlyStart;

      if (earlyStart.isBefore(m_dataDate))
      {
         if (earlyStart.isActual())
         {
            earlyStart = AnnotatedDateTime.fromActual(earlyStart.getRelation(), m_dataDate);
         }
         else
         {
            // very dubious logic here
            earlyStart = AnnotatedDateTime.from(null, getNextWorkStart(task, m_dataDate));
            start = AnnotatedDateTime.fromActual(null, start.getValue());
            task.setActualStart(start.getValue());
         }
      }

      if (!earlyFinish.isActual())
      {
         if (earlyFinish.isBefore(m_dataDate))
         {
            earlyFinish = AnnotatedDateTime.from(null, m_dataDate);
         }

         if (earlyFinish.isBefore(earlyStart))
         {
            if (earlyFinish.isActual())
            {
               earlyFinish = AnnotatedDateTime.fromActual(null, earlyStart.getValue());
            }
            else
            {
               earlyFinish = earlyStart;
            }
         }
      }

      if (lateStart.isAfter(lateFinish))
      {
         lateStart = lateFinish;
      }

      LocalDateTime earlyStartValue = task.getCalendar().getNextWorkStart(earlyStart.getValue());
      LocalDateTime earlyFinishValue = earlyStart.getValue().isEqual(earlyFinish.getValue()) ? earlyStartValue : earlyFinish.getValue();

      task.setStart(start.isActual() ? start.getValue() : earlyStartValue);
      task.setFinish(earlyFinish.isActual() ? earlyFinish.getValue() : earlyFinishValue);

      if (earlyStart.isActual())
      {
         if (task.getCalendar().getWork(m_dataDate, task.getStart(), TimeUnit.HOURS).getDuration() <= 0)
         {
            task.setActualStart(task.getStart());
         }
      }

      if (earlyFinish.isActual() || lateFinish.isActual())
      {
         if (task.getCalendar().getWork(m_dataDate, task.getFinish(), TimeUnit.HOURS).getDuration() <= 0)
         {
            task.setActualStart(task.getStart());
            task.setActualFinish(task.getFinish());
         }
      }

      // Only align the late start with a work start if
      // we have distinct late start and late finish dates.
      LocalDateTime lateStartValue = lateStart.isBefore(lateFinish) ? task.getCalendar().getNextWorkStart(lateStart.getValue()) : lateStart.getValue();

      task.setEarlyStart(earlyStartValue);
      task.setEarlyFinish(earlyFinishValue);
      task.setLateStart(lateStartValue);
      task.setLateFinish(lateFinish.getValue());
      task.setDuration(task.getEffectiveCalendar().getWork(task.getStart(), task.getFinish(), TimeUnit.HOURS));

      // P6 moves the planned start/finish dates for unstarted activities
      if (task.getActualStart() == null)
      {
         task.setPlannedStart(task.getStart());
         task.setPlannedFinish(task.getFinish());
         task.setPlannedDuration(task.getDuration());
      }

      if (task.getActualStart() == null || task.getActualFinish() == null)
      {
         task.setRemainingEarlyStart(task.getEarlyStart());
         task.setRemainingEarlyFinish(earlyFinishValue);
         task.setRemainingLateStart(task.getLateStart());
         task.setRemainingLateFinish(lateFinish.getValue());
      }

      task.setRemainingDuration(task.getEffectiveCalendar().getWork(task.getRemainingEarlyStart(), task.getEarlyFinish(), TimeUnit.HOURS));
      if (task.getActualStart() != null)
      {
         LocalDateTime finish = task.getActualFinish() == null ? task.getRemainingEarlyStart() : task.getActualFinish();
         task.setActualDuration(task.getEffectiveCalendar().getWork(task.getActualStart(), finish, TimeUnit.HOURS));
         task.setPercentageComplete(calculateDurationPercentComplete(task));
      }
      
      task.getResourceAssignments().forEach(this::updateDates);

      if (earlyStart.getRelation() != null)
      {
         earlyStarts.forEach(a -> a.getRelation().setDriving(true));
      }

      if (earlyFinish.getRelation() != null)
      {
         earlyFinish.getRelation().setDriving(true);
      }
   }

   /**
    * Return the earliest of the current date and the new date.
    *
    * @param currentDate current date
    * @param newDate new date
    * @return earliest date
    */
   private AnnotatedDateTime updateIfBefore(AnnotatedDateTime currentDate, AnnotatedDateTime newDate)
   {
      if (currentDate == null)
      {
         return newDate;
      }

      return newDate.isBefore(currentDate) ? newDate : currentDate;
   }

   /**
    * Return the latest of the current date and the new date.
    *
    * @param currentDate current date
    * @param newDate new date
    * @return latest date
    */
   private AnnotatedDateTime updateIfAfter(AnnotatedDateTime currentDate, AnnotatedDateTime newDate)
   {
      if (currentDate == null)
      {
         return newDate;
      }

      return newDate != null && newDate.isAfter(currentDate) ? newDate : currentDate;
   }

   /**
    * Adjust a Level of Effort activity finish date back to the end of the last working period.
    *
    * @param task parent task
    * @param finish finish date
    * @return adjusted date
    */
   private LocalDateTime adjustFinish(Task task, LocalDateTime finish)
   {
      if (finish == null)
      {
         return null;
      }

      ProjectCalendar calendar = task.getEffectiveCalendar();
      LocalDateTime previousWorkFinish = calendar.getPreviousWorkFinish(finish);

      if (calendar.getWork(previousWorkFinish, finish, TimeUnit.HOURS).getDuration() == 0)
      {
         return previousWorkFinish;
      }

      return finish;
   }

   /**
    * Schedule WBS Summary activities.
    */
   private void wbsSummaryPass()
   {
      List<Task> activities = m_file.getTasks().stream().filter(PrimaveraScheduler::isWbsSummary).collect(Collectors.toList());
      if (activities.isEmpty())
      {
         return;
      }

      for (Task activity : activities)
      {
         wbsSummaryPass(activity);
      }
   }

   /**
    * Schedule a WBS Summary activity.
    *
    * @param task target task
    */
   private void wbsSummaryPass(Task task)
   {
      Task wbs = task.getParentTask();
      if (wbs == null)
      {
         return;
      }

      // These values can be used directly from the parent WBS
      task.setStart(wbs.getStart());
      task.setFinish(wbs.getFinish());
      task.setActualStart(wbs.getActualStart());
      task.setActualFinish(wbs.getActualFinish());

      // These values can only be rolled up from not started or in progress child activities of the WBS
      // so we need to descend the wbs hierarchy find all child activities which match these criteria.
      List<Task> childTasks = allWbsChildTasks(wbs, new ArrayList<>());
      task.setEarlyStart(childTasks.stream().map(Task::getEarlyStart).filter(Objects::nonNull).min(Comparator.naturalOrder()).orElse(null));
      task.setEarlyFinish(childTasks.stream().map(Task::getEarlyFinish).filter(Objects::nonNull).max(Comparator.naturalOrder()).orElse(null));
      task.setRemainingEarlyStart(childTasks.stream().map(Task::getRemainingEarlyStart).filter(Objects::nonNull).min(Comparator.naturalOrder()).orElse(null));
      task.setRemainingEarlyFinish(childTasks.stream().map(Task::getRemainingEarlyFinish).filter(Objects::nonNull).max(Comparator.naturalOrder()).orElse(null));
      task.setLateStart(childTasks.stream().map(Task::getLateStart).filter(Objects::nonNull).min(Comparator.naturalOrder()).orElse(null));
      task.setLateFinish(childTasks.stream().map(Task::getLateFinish).filter(Objects::nonNull).max(Comparator.naturalOrder()).orElse(null));
      task.setRemainingLateStart(childTasks.stream().map(Task::getRemainingLateStart).filter(Objects::nonNull).min(Comparator.naturalOrder()).orElse(null));
      task.setRemainingLateFinish(childTasks.stream().map(Task::getRemainingLateFinish).filter(Objects::nonNull).max(Comparator.naturalOrder()).orElse(null));
   }

   /**
    * Find the activities with the latest early finish dates
    * and work back through their driving predecessors setting the
    * longest path flag.
    *
    * @param activities activities to consider for the longest path flag
    */
   private void calculateLongestPath(List<Task> activities)
   {
      LocalDateTime earlyFinish = activities.stream().map(Task::getEarlyFinish).max(Comparator.naturalOrder()).orElse(null);

      activities.stream()
         .filter(t -> t.getEarlyFinish() != null && t.getEarlyFinish().isEqual(earlyFinish))
         .forEach(this::applyLongestPath);

      m_file.getTasks().stream()
         .filter(t -> t.getActivityType() == ActivityType.WBS_SUMMARY && t.getEarlyFinish() != null && t.getEarlyFinish().isEqual(earlyFinish))
         .forEach(t -> t.setLongestPath(true));
   }

   /**
    * Set the longest path flag for the supplied task
    * and any driving predecessor tasks.
    *
    * @param task task on the longest path
    */
   private void applyLongestPath(Task task)
   {
      if (task.getLongestPath())
      {
         return;
      }

      task.setLongestPath(true);
      task.getPredecessors().stream()
         .filter(Relation::getDriving)
         .map(Relation::getPredecessorTask)
         .forEach(this::applyLongestPath);
   }

   /**
    * Descend through the entire hierarchy beneath a WBS entry collecting all child tasks.
    *
    * @param wbs WBS entry
    * @param childTasks list to populated with child tasks
    * @return list of child tasks
    */
   private List<Task> allWbsChildTasks(Task wbs, List<Task> childTasks)
   {
      childTasks.addAll(wbs.getChildTasks().stream().filter(t -> !t.getSummary() && t.getActivityType() != ActivityType.WBS_SUMMARY && t.getActualFinish() == null).collect(Collectors.toList()));
      wbs.getChildTasks().stream().filter(Task::getSummary).forEach(t -> allWbsChildTasks(t, childTasks));
      return childTasks;
   }

   /**
    * Given a task and a finish date potentially at the start of a working period,
    * determine if there is an earlier equivalent finish date at the end of working
    * period which can be used instead.
    *
    * @param task parent task
    * @param date potential finish date
    * @return finish date
    */
   private LocalDateTime getEquivalentPreviousWorkFinish(Task task, LocalDateTime date)
   {
      if (useTaskEffectiveCalendar(task))
      {
         return getEquivalentPreviousWorkFinish(task.getEffectiveCalendar(), date);
      }

      return getResourceAssignmentStream(task).map(r -> getEquivalentPreviousWorkFinish(r.getEffectiveCalendar(), date)).max(Comparator.naturalOrder()).orElse(null);
   }

   /**
    * Given a calendar and a finish date potentially at the start of a working period,
    * determine if there is an earlier equivalent finish date at the end of working
    * period which can be used instead.
    *
    * @param calendar target calendar
    * @param date potential finish date
    * @return finish date
    */
   private LocalDateTime getEquivalentPreviousWorkFinish(ProjectCalendar calendar, LocalDateTime date)
   {
      LocalDateTime previousWorkFinish = calendar.getPreviousWorkFinish(date);
      if (calendar.getWork(previousWorkFinish, date, TimeUnit.HOURS).getDuration() == 0)
      {
         return previousWorkFinish;
      }
      return date;
   }

   /**
    * Adjust a start date which sits on or after a working period to the
    * start of the next working period.
    *
    * @param task parent task
    * @param date date
    * @return adjusted date
    */
   private LocalDateTime getEquivalentNextWorkStart(Task task, LocalDateTime date)
   {
      if (useTaskEffectiveCalendar(task))
      {
         return getEquivalentNextWorkStart(task.getEffectiveCalendar(), date);
      }

      return getResourceAssignmentStream(task).map(r -> getEquivalentNextWorkStart(r.getEffectiveCalendar(), date)).min(Comparator.naturalOrder()).orElse(null);
   }

   private LocalDateTime getEquivalentNextWorkStart(ProjectCalendar calendar, LocalDateTime date)
   {
      LocalDateTime adjustedDate = calendar.getNextWorkStart(date);
      if (calendar.getWork(date, adjustedDate, TimeUnit.MINUTES).getDuration() == 0)
      {
         return adjustedDate;
      }
      return date;
   }

   /**
    * Retrieve a stream of resource assignments which can be used when scheduling the parent task.
    *
    * @param task parent task
    * @return resource assignment stream
    */
   private Stream<ResourceAssignment> getResourceAssignmentStream(Task task)
   {
      return task.getResourceAssignments().stream().filter(r -> r.getResource() != null && r.getResource().getType().isTimeBased() && r.getUnits().doubleValue() > 0.0);
   }

   /**
    * Add work to a date using the effective calendar from a resource assignment.
    *
    * @param assignment resource assignment
    * @param date date
    * @param work amount of work to add
    * @return date plus work
    */
   private LocalDateTime getDateFromWork(ResourceAssignment assignment, LocalDateTime date, Duration work)
   {
      return getDateFromWork(assignment.getResource().getCalendar(), assignment.getUnits(), date, work);
   }

   private LocalDateTime getDateFromWork(ProjectCalendar calendar, Number units, LocalDateTime date, Duration work)
   {
      double unitsValue = getUnitsValue(units);

      if (unitsValue == 0)
      {
         return date;
      }

      if (unitsValue != 100.0)
      {
         work = Duration.getInstance((work.getDuration() * 100.0) / unitsValue, work.getUnits());
      }

      return m_dateCalculator.getDate(calendar, date, work);
   }

   private double getUnitsValue(Number units)
   {
      double unitsValue = units.doubleValue();

      // P6 writes small units values to XER files.
      // The P6 UI shows these as zero, and the scheduler treats them as zero.
      return unitsValue < 0.001 ? 0 : unitsValue;
   }

   /**
    * Given a task and a start date potentially at the end of a working period,
    * determine if there is a later equivalent start date at the start of the
    * next working period.
    *
    * @param task parent task
    * @param date potential start date
    * @return start date
    */
   private LocalDateTime getNextWorkStart(Task task, LocalDateTime date)
   {
      if (task.getActualFinish() != null)
      {
         return date;
      }

      if (useTaskEffectiveCalendar(task))
      {
         return task.getEffectiveCalendar().getNextWorkStart(date);
      }

      return getResourceAssignmentStream(task).map(r -> r.getEffectiveCalendar().getNextWorkStart(date)).min(Comparator.naturalOrder()).orElse(null);
   }

   private boolean hasRemainingDuration(Task task)
   {
      Duration remaining;
      if (useTaskEffectiveCalendar(task))
      {
         remaining = task.getRemainingDuration();
      }
      else
      {
         remaining = getResourceAssignmentStream(task).map(ResourceAssignment::getRemainingWork).max(Comparator.naturalOrder()).orElse(null);
      }

      return remaining.getDuration() != 0.0;
   }

   private boolean hasActualDuration(Task task)
   {
      Duration actual;
      if (useTaskEffectiveCalendar(task))
      {
         actual = task.getActualDuration();
      }
      else
      {
         actual = getResourceAssignmentStream(task).map(ResourceAssignment::getActualWork).max(Comparator.naturalOrder()).orElse(null);
      }

      return actual.getDuration() != 0.0;
   }

   /**
    * Retrieve the constraint type and default to As Soon As Possible
    * if no constraint type is present.
    *
    * @param task target task
    * @return constraint type
    */
   private ConstraintType getConstraintType(Task task)
   {
      return task.getConstraintType() == null ? ConstraintType.AS_SOON_AS_POSSIBLE : task.getConstraintType();
   }

   /**
    * Returns true if the supplied timestamp is in any of the working time ranges
    * (including at the start and end) from the task's effective calendar.
    *
    * @param task target task
    * @param date timestamp to test
    * @return true if the timestamp is withing the working time ranges
    */
   private boolean isWorkingTime(Task task, LocalDateTime date)
   {
      LocalTime time = date.toLocalTime();
      for (LocalTimeRange range : task.getEffectiveCalendar().getHours(date))
      {
         if (time.isBefore(range.getStart()))
         {
            return false;
         }

         if (!LocalTime.MIDNIGHT.equals(range.getEnd()) && time.isAfter(range.getEnd()))
         {
            continue;
         }

         return true;
      }

      return false;
   }

   private LocalDateTime getNearestEquivalentDate(Task predecessorTask, LocalDateTime date)
   {
      LocalDateTime previousDate = predecessorTask.getEffectiveCalendar().getPreviousWorkFinish(date);
      LocalDateTime followingDate = getNextWorkStart(predecessorTask, date);
      long previousDistance = previousDate.until(date, ChronoUnit.MINUTES);
      long followingDistance = date.until(followingDate, ChronoUnit.MINUTES);
      return previousDistance < followingDistance ? previousDate : followingDate;
   }
   
   private ProjectFile m_file;
   private PrimaveraDateCalculator m_dateCalculator;
   private LocalDateTime m_dataDate;
   private LocalDateTime m_projectStartDate;
   private LocalDateTime m_forwardPassFinishDate;
   private LocalDateTime m_backwardPassFinishDate;
   private boolean m_useExpectedFinish;
}
